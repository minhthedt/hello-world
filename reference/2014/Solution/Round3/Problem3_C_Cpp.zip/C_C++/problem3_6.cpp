#include <iostream>
#include <vector>

using namespace std;

int maps[1001][1001];
int value[10][1001];
int preval[10][1001];
int tmpval[10][1001];
int divide[] = {2, 3, 5, 7, 11, 13, 17, 19, 23, 29};
int pageNum, linkNum, startNum, maxLen;

int main() {
	FILE *infile;
	FILE *outfile;
	
	infile = fopen("C-large.in", "r");
	outfile = fopen("result.out", "w");
	
	int cases;
	fscanf(infile, "%d", &cases);

	while (cases > 0) {
		
		int i, j, k;

		fscanf(infile, "%d %d %d %d", &pageNum, &linkNum, &startNum, &maxLen);

		vector< vector<int> > from(pageNum + 1);
		
		memset(maps, 0, sizeof(int) * 1001 * 1001);
		memset(value, 0, sizeof(int) * 10 * 1001);
		memset(tmpval, 0, sizeof(int) * 10 * 1001);

		for (i = 0; i < linkNum; i++) {
			int start, end;
			fscanf(infile, "%d %d", &start, &end);
			if (start == 1) {
				//continue;
			}
			if (maps[end][start] == 0) {
				from[end].push_back(start);
			}
			maps[end][start] = maps[end][start] + 1;
		}

		for (i = 0; i < 10; i++) {
			tmpval[i][1] = 1;
		}
		
		int fromSize, start, arrive, addval;
		int to[1001];
		int tmp[1001];
		memset(to, 0, sizeof(int) * (1001));
		memset(tmp, 0, sizeof(int) * (1001));
		to[1] = 1;
		
		for (i = 0; i < maxLen; i++) {
			memcpy(preval, tmpval, 4 * 10 * 1001);
			memset(tmpval, 0, 4 * 10 * 1001);
			for (arrive = 1; arrive <= pageNum; arrive++) {
				if (to[arrive] == 0) {
					continue;
				}
				fromSize = from[arrive].size();
				for (j = 0; j < fromSize; j++) {
					start = from[arrive].at(j);
					for (k = 0; k < startNum; k++) {
						addval = preval[k][arrive] * maps[arrive][start];
						tmpval[k][start] = (tmpval[k][start] + addval) % divide[k];
						value[k][start] = (value[k][start] + addval) % divide[k];
					}
					tmp[start] = 1;
				}
			}
			memcpy(to, tmp, sizeof(int) * 1001);
			memset(tmp, 0, sizeof(int) * 1001);
		}
		
		for (i = 0; i < startNum - 1; i++) {
			fprintf(outfile, "%d ", value[i][i+2]);
		}		
		fprintf(outfile, "%d \n", value[startNum-1][startNum+1]);

		cases--;
	}
	
	fclose(infile);
	fclose(outfile);
	return 0;
}
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int L;
int **link;
int *linkSize;
int getNumberOfPath(int start, int length);

void main()
{
	FILE *in, *out;
	int T;
	int i = 0, j = 0;
	int Numbers[10] = { 2, 3, 5, 7, 11, 13, 17, 19, 23, 29 };
	
	//file I/O
	if ((in = fopen("C-small.in", "r")) == 0)
	//if ((in = fopen("input.txt", "r")) == 0)
	{
		printf("Input File error!!\n");
		return;
	}

	if ((out = fopen("output.txt", "w")) == 0)
	{
		printf("Output File error!!\n");
		return;
	}

	//Read Number of TestCase
	fscanf(in, "%d", &T);
	
	for (i = 0; i < T; i++)
	{
		//��������  ��  N,  ��ũ��  ��  M,  �������  ��  K,  �����  �ִ�  ����  L
		int N, M, K;
		int temp=0;
		

		fscanf(in, "%d %d %d %d", &N, &M, &K, &L);
		link = (int **)malloc(sizeof(int*)*N);
		linkSize = (int *)malloc(sizeof(int)*N);
		memset(linkSize, 0x00, sizeof(int)*N);

		for (j = 0; j < N; j++)
		{
			link[j] = (int *)malloc(sizeof(int)*M);
			memset(link[j], 0x00, sizeof(int)*M);
		}

		for (j = 0; j < M; j++)
		{
			int page1, page2;
			fscanf(in, "%d %d", &page1, &page2);
			link[page1 - 1][linkSize[page1 - 1]++] = page2;
		}

		/*
		for (j = 0; j < N; j++)
		{
			int k;
			for (k = 0; k < M; k++)
			{
				printf("%d,", link[j][k]);
			}
			printf("\n");
		}
		
		printf("size:\n");
		for (j = 0; j < N; j++)
		{
			printf("%d,", linkSize[j]);
			temp += linkSize[j];
		}
		printf("\n");
		printf("%d\n", temp);
		*/

		for (j = 2; j < K + 2; j++)
		{
			unsigned int result;
			result = getNumberOfPath(j, 0);
			fprintf(out,"%d ", result % Numbers[j - 2]);
		}
		fprintf(out,"\n");

		if (linkSize)
		{
			free(linkSize);
		}
		
		if (link)
		{
			for (j = 0; j < N; j++)
			{
				free(link[j]);
			}
			free(link);
		}
	}



	//free FD
	if (in != 0)
	{
		fclose(in);
	}

	if (in != 0)
	{
		fclose(out);
	}

	printf("End!!!\n");
	return;
}

//��������  ��  N,  ��ũ��  ��  M,  �������  ��  K,  �����  �ִ�  ����  L
int getNumberOfPath(int start, int length)
{
	int result = 0;
	int i;

	//end point
	if (start == 1)
	{
		result++;
	}

	if (length == L)
	{
		return result;
	}

	//next
	length++;
	for (i = 0; i < linkSize[start - 1]; i++)
	{
		result += getNumberOfPath(link[start - 1][i], length);
	}

	return result;
}

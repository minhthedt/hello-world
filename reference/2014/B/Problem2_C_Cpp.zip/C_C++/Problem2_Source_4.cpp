// Problem_2.cpp : Defines the entry point for the console application.
#include <stdlib.h>
#include <stdio.h>
#include <tchar.h>

int no_disc;

int *discs;
int *day2;
int *day3;

int day2first;
int day3first;

int test_res = 0;

void printdisc(int *discs)
{
	printf("\t");
	for(int i=0;i<no_disc;i++)
		printf("%d ",discs[i]);
}

bool compare(int *disc1, int *disc2)
{
	for(int i=0;i<no_disc;i++)
	{
			if(disc1[i] != disc2[i])
				return 0;
	}
	return 1;
}

bool comparediscs()
{
		if(compare(discs,day2)){ if(!day3first) day2first = 1; test_res = 1;
		return 1;}
		if(compare(discs,day3)){ if(!day2first) day3first = 1; test_res = 1;
		return 1;}
}
void towers(int num, char frompeg, char topeg, char auxpeg)
{
	
	if(test_res)
		return;
    if (num == 1)
    {
       
		discs[0] = (topeg == 'E')?3:(topeg == 'S')?1:2;
		comparediscs();
		return;
    }
    towers(num - 1, frompeg, auxpeg, topeg);
   
	discs[num-1] = (topeg == 'E')?3:(topeg == 'S')?1:2;
	if(!test_res)
		comparediscs();
	else 
		return;
	towers(num - 1, auxpeg, topeg, frompeg);
}
void readInput(char *filename)
{
	FILE *in;
	FILE *out;

	in = fopen(filename,"r");
	if(!in)
		return;
	out = fopen("output.txt","w");
	if(!out)
		return;

	int no_tc;
	
	int *list;
	int i =3;
	int itr = 0;
	int listidx = -1;
	fscanf(in,"%d",&no_tc);
	//printf("\n No of testcases[%d]",no_tc);

	while(no_tc){
		fscanf(in,"%d",&no_disc);
		//printf("\n\n\nNo of Disc [%d]\n",no_disc);
		day2first = 0;
		day3first = 0;
		test_res = 0;

		discs = (int *)malloc(sizeof(int) * no_disc);
		for(int disk = 0;disk < no_disc;disk++)
			discs[disk] = 1;

		day2 = (int *)malloc(sizeof(int) * no_disc);
		day3 = (int *)malloc(sizeof(int) * no_disc);

		for(int i = 0;i<no_disc;i++)
			fscanf(in,"%d",&(day2[no_disc - 1 -i]));
		for(int i = 0;i<no_disc;i++)
			fscanf(in,"%d",&(day3[no_disc - 1 -i]));
	//	printdisc(day2);
	//	printdisc(day3);
		towers(no_disc,'S','T','E');
		
		if(day2first){
			printf("1\n");
			fprintf(out,"%d\n",1);
		}
		//else if(day2first == 0 && day3first == 0)
		//	printf("Result 1");
		else{
			printf("0\n");
			fprintf(out,"%d\n",0);
		}
		no_tc--;
		//no_tc = 0;
	}
	fclose(in);
	fclose(out);

}

int _tmain(int argc, _TCHAR* argv[])
{
	//readInput("input.txt");
	readInput("B-small.in");
	//readInput("B-large.in");
	//getchar();
	return 0;
}


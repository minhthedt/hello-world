#include <iostream>
#include <vector>
#include <fstream>

using namespace std;

const int TOTALN = 100000;

int secondDayTower[TOTALN];
int thirdDayTower[TOTALN];
int brahmaTower[TOTALN];

int totalCount = 0;

int findSecondDayTower = 0;
int findThirdDayTower = 0;

int nNum;

void dataReset()
{
	memset(secondDayTower, 0, sizeof(int) * TOTALN);
	memset(thirdDayTower, 0, sizeof(int) * TOTALN);
	memset(brahmaTower, 0, sizeof(int) * TOTALN);

	totalCount = 0;

	findSecondDayTower = 0;
	findThirdDayTower = 0;

	nNum = 0;
}

void compareTower()
{
	if (findSecondDayTower == 0) {
		findSecondDayTower = totalCount;
		// secondDayTower
		for (int i = 0; i < nNum; i++) {
			if (secondDayTower[i] != brahmaTower[i]) {
				findSecondDayTower = 0;
				break;
			}
		}
	}

	if (findThirdDayTower == 0) {
		findThirdDayTower = totalCount;
		// thirdDayTower
		for (int i = 0; i < nNum; i++) {
			if (thirdDayTower[i] != brahmaTower[i]) {
				findThirdDayTower = 0;
				break;
			}
		}
	}
}

void brahma(int n, int from, int tmp, int to)
{
	if (findSecondDayTower != 0 && findThirdDayTower != 0) {
		return;
	}

	if (n == 1) {
		brahmaTower[n-1] = to;
		totalCount++;
		// 1 : from -> to
		compareTower();
	}
	else {
		brahma(n-1, from, to, tmp);
		// print n : from -> to
		brahmaTower[n-1] = to;
		totalCount++;
		compareTower();
		brahma(n-1, tmp, from, to);
	}
}

int checkBrahmaTower(ifstream *fin, ofstream *fout)
{
	int i;
	int processOK = 0;

	dataReset();

	*fin >> nNum;

	for (i = nNum-1; i >= 0; i--) {
		*fin >> secondDayTower[i];
		secondDayTower[i]--;
	}

	for (i = nNum-1; i >= 0; i--) {
		*fin >> thirdDayTower[i];
		thirdDayTower[i]--;
	}

	info.n = nNum;
	info.from = 0;
	info.tmp = 2;
	info.to = 1;

	brahma(nNum, 0, 2, 1);

	if (findSecondDayTower == 0 || findThirdDayTower == 0) {
		// error
		processOK = 0;
	}
	else {
		if (findSecondDayTower < findThirdDayTower) {
			// ok
			processOK = 1;
		}
	}
		
	*fout << processOK << endl;

	return 0;
}

int main(int argc, char *argv[])
{
	ifstream fin;
	ofstream fout;
	
	int caseNum = 0;
	
	fin.open(argv[1]);
	fout.open(argv[2]);

	fin >> caseNum;

	for (int i = 0; i < caseNum; i++) {
		checkBrahmaTower(&fin, &fout);
	}

	fin.close();
	fout.close();

	return 0;
}

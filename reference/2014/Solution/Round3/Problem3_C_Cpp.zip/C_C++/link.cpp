#include <iostream>
#include <vector>
using namespace std;

const bool debug = false;

typedef unsigned long long uint64_t;

typedef vector<uint64_t> Row;
typedef vector<Row> Mat;


const uint64_t mod[] = {2LL, 3LL, 5LL, 7LL, 11LL, 13LL, 17LL, 19LL, 23LL, 29LL};


////////////////////////////////////////////////////////////////////////////////
// helper
template<class T>
ostream& operator<<(ostream& os, const vector<T>& v)
{
    typename vector<T>::const_iterator it;
    for (it = v.begin(); it != v.end(); ++it)
        os << *it << " ";
    return os;
}

ostream& operator<<(ostream& os, const Mat& v)
{
    Mat::const_iterator it;
    for (it = v.begin(); it != v.end(); ++it)
        os << *it << endl;
    return os;
}

uint64_t totalways;

void bfs(const Mat& edges, uint64_t from, uint64_t l, uint64_t ways, uint64_t count)
{
    if (debug) {
        for (int i = 0; i < count * 2; ++i)
            cout << ' ';
        cout << "| " << count << ' ' << from+1  << ' ' << ways << ' ' << endl;
    }

    if (count > l)
        return;

    if (from == 0) {
        if (debug)
            cout << "$$ found " << ways << endl;
        totalways += ways;
    }

    const Row& edge = edges[from];

    for (size_t i = 0; i < edge.size(); ++i) {
        uint64_t nedge = edge[i];
        if (nedge)
            bfs(edges, i, l, ways * nedge, count + 1);
    }
}

Mat multiply(const Mat& l, const Mat& r)
{
    size_t size = l.size();
    Mat ret = l;

    for (size_t row = 0; row < size; ++row) {
        for (size_t col = 0; col < size; ++col) {
            uint64_t sum = 0;
            for (size_t inner = 0; inner < size; ++inner) {
                sum += l[row][inner] * r[inner][col];
            }
            ret[row][col] = sum;
        }
    }
    return ret;
}

vector<uint64_t> solve(const Mat& edges, uint64_t k, uint64_t l)
{
    // 1. do calculation
    vector<Mat> e(l);
    e[0] = edges;
    for (size_t i = 1; i < l; ++i) {
        e[i] = multiply(e[0], e[i - 1]);
        // cout << i << "th" << endl;
        // cout << e[i] << endl;
    }

    vector<uint64_t> res;
    for (size_t i = 1; i < k + 1; ++i) {
        uint64_t sum = 0;
        for (size_t j = 0; j < l; ++j) {
            sum += e[j][i][0] % mod[i - 1];
        }
        res.push_back(sum % mod[i - 1]);
    }

    return res;
}

int main()
{
    int ncase;
    cin >> ncase;
    while (ncase--) {
        uint64_t n, m, k, l;
        cin >> n >> m >> k >> l;

        Mat edges(n);
        for (size_t i = 0; i < n; i++)
            edges[i].resize(n);

        for (size_t i = 0; i < m; i++) {
            uint64_t from, to;

            cin >> from >> to;
            edges[from - 1][to - 1]++;
        }
        if (debug) {
            cout << "------------------------------------------------------------" << endl;
            cout << edges;
        }

        vector<uint64_t> res = solve(edges, k, l);
        // for (size_t i = 0; i < res.size(); i++) {
        //     cout << res[i] % mod[i];
        //     if (i < res.size() - 1)
        //         cout << " ";
        // }
        // cout << endl;
        cout << res << endl;
    }
    return 0;
}

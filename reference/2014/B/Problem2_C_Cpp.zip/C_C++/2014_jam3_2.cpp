// 2014_jam3_2.cpp : �ܼ� ���� ���α׷��� ���� �������� �����մϴ�.
//

#include "stdafx.h"
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <stack>
using namespace std;

#define DAYS 2;
#define SMALL 1

//stack<int> tower1;
//stack<int> tower2;
//stack<int> tower3;


struct brama_tower
{
	stack<int> tower[4];
};

brama_tower solution;
brama_tower day2;
brama_tower day3;
int check = 0;
FILE *fp, *afp;

void check_answer()
{
	if(solution.tower[1] == day2.tower[1] && 
		solution.tower[2] == day2.tower[2] &&
		solution.tower[3] == day2.tower[3]){
		check = 1;
		printf("day2 ");
	}
	if(solution.tower[1] == day3.tower[1] && 
		solution.tower[2] == day3.tower[2] &&
		solution.tower[3] == day3.tower[3]){
		check = 1;
		printf("day3 ");
	}
}
#if SMALL
void brama(int n, stack<int> *tower1, stack<int> *tower2, stack<int> *tower3)
{
	if(check == 0){
		if (n == 1){
			tower3->push(tower1->top());
			tower1->pop();		
			check_answer();
		}
		else
		{
			brama((n - 1), tower1, tower3, tower2);
			tower3->push(tower1->top());
			tower1->pop();		
			check_answer();
			if(check == 0)
				brama((n - 1), tower2, tower1, tower3);				
		}
	}
}
#else

//void brama(int n, stack<int> *tower1, stack<int> *tower2, stack<int> *tower3)
void brama(int n, int a, int b, int c)
{
	int complete = 0;
	stack<int> tmp;

	while(!complete) {

		while(n > 1)
		{
			tmp.push(c);
			tmp.push(b);
			tmp.push(a);
			tmp.push(n);
			n--;

			tmp.push(c);
			c = b;
			b = tmp.top();
			tmp.pop();
		}

		solution.tower[c].push(solution.tower[a].top());
		solution.tower[a].pop();
		check_answer();
		if(check == 1)
			break;

		if(!tmp.empty())
		{
			n = tmp.top();
			tmp.pop();
			a = tmp.top();
			tmp.pop();
			b = tmp.top();
			tmp.pop();
			c = tmp.top();
			tmp.pop();
			n--;
			
			solution.tower[c].push(solution.tower[a].top());
			solution.tower[a].pop();
			check_answer();
			if(check == 1)
				break;
			
			tmp.push(a);
			a = b;
			b = tmp.top();
			tmp.pop();
		}
		else
			complete = 1;		
    }
}
#endif

void free_brama(brama_tower *tower)
{
	while(!tower->tower[1].empty())
		tower->tower[1].pop();
	while(!tower->tower[2].empty())
		tower->tower[2].pop();
	while(!tower->tower[3].empty())
		tower->tower[3].pop();
}

void init_brama(int N)
{
	int number;

	for(int i = N; i > 0; i--)
	{
		fscanf_s(fp, "%d", &number);
		day2.tower[number].push(i);
	}
	for(int i = N; i > 0; i--)
	{
		fscanf_s(fp, "%d", &number);
		day3.tower[number].push(i);
	}
	for(int i = N; i > 0; i--)
	{
#if SMALL
		solution.tower[1].push(i);
#else
		solution.tower[1].push(i);
#endif
	}
}
int _tmain(int argc, _TCHAR* argv[])
{

	int T = 0;
	int N = 0;
	int day = 0;

	fopen_s(&fp, "test.txt", "r");
	fopen_s(&afp, "answer2", "w");
	fscanf_s(fp, "%d", &T);
	
    while (T-- > 0)
    {
		check = 0;
		fscanf_s(fp, "%d", &N);
		printf("start T=%d N=%d\n",T, N);

		init_brama(N);

#if SMALL
		brama(N, &solution.tower[1], &solution.tower[3], &solution.tower[2]);
#else
		brama(N, 1, 3, 2);
#endif
		printf("answer %d\n", check);
		fprintf(afp, "%d\n", check);
		free_brama(&solution);
		free_brama(&day2);
		free_brama(&day3);
    }
	fclose(afp);
	return 0;
}


#include <cstdio>
#include <string>
#include <iostream>

using namespace std;

int status[2][100002];
int day;
string hanoi(int from, int to, int mid, int n) {

  if (n == 1) {
    if (status[day][n] == from) return "0";
    else if (status[day][n] == to) return "1";
    return "";
  }
  
  if (status[day][n] == from) {
    string ret = hanoi(from, mid, to, n-1);
    if ((int)ret.size() != 0) return "0" + ret;
    else return "";
  } else if (status[day][n] == to) {
    string ret = hanoi(mid, to, from, n-1);
    if ((int)ret.size() != 0) return "1" + ret;
    else return "";
  }

  return "";
}

int main() {

  int tc;

  cin >> tc;
  while(tc--) {
    int n;
    cin >> n;

    for (int i = 0; i < 2; i++) {
      for (int j = n; j > 0; j--) {
	cin >> status[i][j];
      }
    }

    day = 0;
    string fday = hanoi(1, 2, 3, n);
    day = 1;
    string sday = hanoi(1, 2, 3, n);

    if ((int)fday.size() == 0 || (int)sday.size() == 0) {
      cout << "0" << endl;
    } else {
      bool flag = true;
      for (int i = 0; i < n; i++) {
	if (fday[i] > sday[i]) {
	  flag = false;
	  break;
	} else if (fday[i] < sday[i]) {
	  break;
	}
      }

      if (flag) cout << "1" << endl;
      else cout << "0" << endl;
    }
  }
  
  return 0;
}


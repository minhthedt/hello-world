#include <stdio.h>
#include <stdint.h>

#define MAXN 100001

void getNext( char* NewPosScore, char* PosScore, char peg){
	if( peg == 1 ) {NewPosScore[0] = PosScore[0]; NewPosScore[1] = PosScore[2]; NewPosScore[2] = PosScore[1];}
	if( peg == 2 ) {NewPosScore[0] = PosScore[2]; NewPosScore[1] = PosScore[1]; NewPosScore[2] = PosScore[0];}
	if( peg == 3 ) {NewPosScore[0] = PosScore[1]; NewPosScore[1] = PosScore[0]; NewPosScore[2] = PosScore[2];}
}

int testCorrectness(char* P1, char* P2, int ht, char* PosScore, int N){
	char peg1, peg2;
	char s1, s2;
	
//	fprintf(stderr,"ht: %d score: %d %d %d\n", ht, PosScore[0], PosScore[1], PosScore[2]);

	if( ht == N ) return 1;

	peg1 = P1[ht]; peg2 = P2[ht];
	s1 = PosScore[peg1-1];
	s2 = PosScore[peg2-1];

	if( s1 < 0 ) return 0;
	if( s2 < 0 ) return 0;
	if( peg1 == peg2 ){
		char NewPosScore[3];
		getNext(NewPosScore, PosScore, peg1);
		return testCorrectness(P1, P2, ht + 1, NewPosScore, N);
	}

	return s1 < s2;
}

void solveTest(FILE* in, FILE* out){
	char buf[255];
	int N,i;
	char pos;
	char P2[MAXN], P3[MAXN];


	if( !fgets(buf,256,in) ) {fprintf(stderr, "2: Cannot read input\n"); }
	sscanf(buf,"%d", &N);
	fprintf(stderr, "Number of disk is %d\n", N);

	for(i=0; i<N; i++){

		if( !fgets(buf,256,in) ) {fprintf(stderr, "2: Cannot read input\n"); }
		sscanf(buf,"%d", &pos);
		//fprintf(stderr, "%d: %d\n", i, pos);
		P2[i] = pos;
	}

	for(i=0; i<N; i++){

		if( !fgets(buf,256,in) ) {fprintf(stderr, "2: Cannot read input\n"); }
		sscanf(buf,"%d", &pos);
		P3[i] = pos;
	}
	{
		char PosScore[3] = {0,1,-1};
		if( testCorrectness(P2,P3, 0, PosScore, N) ) 
			fprintf(out, "1\n");
		else
			fprintf(out, "0\n");
	}
	
}

int main(int argc, char* argv[]){
	FILE* f, *fout;
	char* file;
	char buf[256];
	int ntests, solution, i;

	if( argc != 2) { fprintf(stderr, "Specify input file\n"); return 0; }
	file = argv[1];
	fprintf(stderr, "Opening %s\n", file);
	f = fopen(file,"r");
	if( !f ) {fprintf(stderr, "Cannot open %s\n", file); }
	if( !fgets(buf,256,f) ) {fprintf(stderr, "1: Cannot read %s\n", file); }

	sscanf(buf,"%d", &ntests);
	fprintf(stderr, "Number of tests is %d\n", ntests);
	fout = fopen("res.out", "w");

	for(i = 0; i<ntests; i++) {
		solveTest(f, fout);
	}

	return 0;
}


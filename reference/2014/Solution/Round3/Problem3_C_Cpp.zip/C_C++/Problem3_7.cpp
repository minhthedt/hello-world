#include <iostream>
#include <vector>
#include <fstream>
#include <iomanip>

using namespace std;


typedef struct
{
	int rem[10];
}MEMO_LIST_T;

int CalculateIterlate(ifstream &fpin, ofstream &fpout);
MEMO_LIST_T DSF_GetPathNum(int start , int end , vector<int> *linkList , int limit, vector<MEMO_LIST_T> *memo, const int *mod, ofstream &fpout);
void MemoAdd(MEMO_LIST_T &cur , MEMO_LIST_T addVal);
void MemoAdd(MEMO_LIST_T &cur , int addVal);

int main()
{
	ifstream fpin;
	int nrTc;
	fpin.open("inputL001.txt");

	if(!fpin.is_open())
	{
		cout << " Fail to open file." << endl;
		return -1;
	}

	fpin >> nrTc;

	ofstream fout;
	fout.open("output.txt");

	for(int i = 0 ; i < nrTc ; i++)
	{
		CalculateIterlate(fpin, fout);
	}

	fpin.close();
	fout.close();
}

int CalculateIterlate(ifstream &fpin, ofstream &fpout)
{
	
	int nrPage , nrLink , nrStart , maxLen;
	vector<int> *linkList = NULL;
	MEMO_LIST_T result;

	int modN[10] = { 2, 3, 5, 7, 11, 13, 17, 19, 23, 29 };

	fpin >> nrPage >> nrLink >> nrStart >> maxLen ;

	linkList = new vector<int> [nrPage+1];

	vector<MEMO_LIST_T> *memo = new vector<MEMO_LIST_T> [nrPage +1];

	int tstart , tend;

	for(int i = 0 ; i < nrLink ; i++)
	{
		fpin >> tstart >> tend;
		linkList[tstart].push_back(tend);
	}
	
	//fpout << "maxLen = " << maxLen << endl;

	for(int p = 0 ; p < nrPage +1 ; p++)
	{
		memo[p].resize(maxLen);

		for(int j = 0 ; j < (int)memo[p].size() ; j++)
		{
			memset(memo[p][j].rem, -1 , 10 * sizeof(int));
		}
	}

	for(int i = 0 ; i < nrStart ; i++)
	{
		result = DSF_GetPathNum(i+2 , 1 , linkList , maxLen , memo, modN,  fpout);
		
		cout << result.rem[i] << " ";
		fpout << result.rem[i];
		fpout << " ";
	}

	cout << endl;
	fpout << endl;

	delete [] linkList;
	delete [] memo;

	return 0;
}

MEMO_LIST_T DSF_GetPathNum(int start , int end , vector<int> *linkList , int limit, vector<MEMO_LIST_T> *memo, const int *mod, ofstream &fpout)
{
	MEMO_LIST_T midVal;
	memset(midVal.rem , 0 , 10 * sizeof(int));

	if(start == end) MemoAdd( midVal , 1);

	if(limit == 0) return midVal;

	if(memo[start][limit-1].rem[0] != -1)
	{
		return memo[start][limit-1];
	}
	MEMO_LIST_T TmpVal;

	for(int i = 0 ; i < (int)linkList[start].size() ; i++)
	{
		TmpVal = DSF_GetPathNum(linkList[start][i] , end , linkList , limit -1 , memo, mod, fpout);
		//midVal +=  TmpVal;
		MemoAdd(midVal , TmpVal);
		//cout << setw(limit*3) << "_" << "limit = " << limit << ", Start = " << start << ", subStart = " << linkList[start][i] << ", end = " << end << " , result = " << TmpVal << endl;
	}

	for(int i = 0 ; i < 10 ; i++)
	{
		midVal.rem[i] %=  mod[i];
	}
	memo[start][limit-1] = midVal;

	return midVal;
}

void MemoAdd(MEMO_LIST_T &cur , MEMO_LIST_T addVal)
{
	for(int i = 0 ; i < 10 ; i++)
	{
		cur.rem[i] += addVal.rem[i];
	}
}

void MemoAdd(MEMO_LIST_T &cur , int addVal)
{
	for(int i = 0 ; i < 10 ; i++)
	{
		cur.rem[i] += addVal;
	}
}

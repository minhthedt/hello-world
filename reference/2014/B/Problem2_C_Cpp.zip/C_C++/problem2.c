#include <stdio.h>
#include <stdlib.h>
#include <memory.h>

#define MAX_N		100001

#define NEXT_STATE(st, c)	(g_states[((st.c1 - 1) * 6) + ((st.c2 - 1) * 2) + (c)])

typedef struct
{
	char c1;
	char c2;
} state_t;

static state_t g_states[3 * 3 * 2] =
{
	/* (1,x) */
	{ 0, 0 }, { 0, 0 },
	{ 1, 3 }, { 3, 2 },
	{ 1, 2 }, { 2, 3 },
	/* (2,x) */
	{ 2, 3 }, { 3, 1 },
	{ 0, 0 }, { 0, 0 },
	{ 2, 1 }, { 1, 3 },
	/* (3,x) */
	{ 3, 2 }, { 2, 1 },
	{ 3, 1 }, { 1, 2 },
	{ 0, 0 }, { 0, 0 },
};

/*
Compare two series (position of stone)
Return 0 : series 1 or 2 is not the shortest solution (or) series 2 is not bigger than series 1
1 : series 1 and 2 is the correct solution (and) series 2 is bigger than series 1
*/
int compare_series(int n, char *pos1, char *pos2)
{
	state_t state1 = { 1, 2 };
	state_t state2 = { 1, 2 };
	int i;
	int bigger = 0;
	int need_compare = 1;

	for (i = 1; i <= n; i++)
	{
		bigger = 0;
		if (state1.c1 == pos1[i])
		{
			state1 = NEXT_STATE(state1, 0);
		}
		else if (state1.c2 == pos1[i])
		{
			bigger = 1;
			state1 = NEXT_STATE(state1, 1);
		}
		else
		{
			return 0;
		}

		if (state2.c1 == pos2[i])
		{
			if (need_compare && bigger)
				return 0;
			state2 = NEXT_STATE(state2, 0);
		}
		else if (state2.c2 == pos2[i])
		{
			if (bigger == 0)
				need_compare = 0;
			state2 = NEXT_STATE(state2, 1);
		}
		else
		{
			return 0;
		}

		if (state1.c1 == 0 || state1.c2 == 0 || state2.c1 == 0 || state2.c2 == 0)
			return 0;
	}

	if (need_compare == 0)
		return 1;

	return 0;
}

int main(int argc, const char* argv[])
{
	FILE *fin = NULL;
	FILE *fout = NULL;
	const char *fin_name = "B-small.in";
	const char *fout_name = "CON";

	int test_set;
	char *series1, *series2;
	int n;
	int t, i, buf;

	if (argc >= 2)
		fin_name = argv[1];
	if ((fin = fopen(fin_name, "rt")) == NULL)
	{
		return 0;
	}

	if (argc >= 3)
		fout_name = argv[2];
	if ((fout = fopen(fout_name, "wt")) == NULL)
	{
		fclose(fin);
		return 0;
	}

	series1 = (char *)malloc(sizeof(char) * MAX_N);
	series2 = (char *)malloc(sizeof(char) * MAX_N);
	fscanf(fin, "%d", &test_set);

	for (t = 0; t < test_set; t++)
	{
		memset(series1, 0, sizeof(char) * MAX_N);
		memset(series2, 0, sizeof(char) * MAX_N);

		fscanf(fin, "%d", &n);
		for (i = 1; i <= n; i++)
		{
			fscanf(fin, "%d", &buf);
			series1[i] = (char)buf;
		}
		for (i = 1; i <= n; i++)
		{
			fscanf(fin, "%d", &buf);
			series2[i] = (char)buf;
		}

		fprintf(fout, "%d\n", compare_series(n, series1, series2));
	}

	free(series1);
	free(series2);
	fclose(fin);
	fclose(fout);
	return 0;
}


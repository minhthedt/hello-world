#include <stdio.h>
#include <stdlib.h>

int second[100000];
int third[100000];
int stick[100000];
char flag;
int total;

/*typedef struct stick{
     int data;
     struct stick *next;
     struct stick *prev;
}Stick;
Stick S[3];*/

void brama(FILE* ofp, int n, int a, int b)
{
     int c, i,j,cnt;//, j, temp;
     
     if(flag == 2)
          return;
     if(n<=1)
     {
//         printf("\n%d° ���� : %d -> %d\n",n ,a, b);
         stick[total-n] = b;
/*         for(j = 0; j < total; j++)
        {
              printf("%d ",stick[j]);
        }*/
         if(flag == 0)
         {
             cnt = 0;
             for(i=0; i<total;i++)
             {
                 if(second[i] == stick[i])
                     cnt++;
                 else
                     break;
             }
             if(cnt == total)
                 flag = 1;
         }
         else if(flag == 1)
         {
             cnt = 0;
             for(i=0; i<total;i++)
             {
                 if(third[i] == stick[i])
                     cnt++;
                 else
                     break;
             }
             if(cnt == total)
                 flag = 2;
         }
/*         for(j = 0; j < 3; j++)
        {
            printf("\n %d ��° ���� : ",j+1);
            for(temp = 1; temp <= stick[j][0]; temp++)
                printf("%d ",stick[j][temp]);
            printf("\n");
        }*/
         return;
     }
     else
     {
         c = 6-a-b;
         
         brama(ofp, n-1,a,c);
//         printf("\n%d° ���� : %d -> %d\n",n ,a, b);
         stick[total-n] = b;
/*         for(j = 0; j < total; j++)
        {
              printf("%d ",stick[j]);
        }  */      
         if(flag == 0)
         {
             cnt = 0;
             for(i=0; i<total;i++)
             {
                 if(second[i] == stick[i])
                     cnt++;
                 else
                     break;
             }
             if(cnt == total)
                 flag = 1;
         }
         else if(flag == 1)
         {
             cnt = 0;
             for(i=0; i<total;i++)
             {
                 if(third[i] == stick[i])
                     cnt++;
                 else
                     break;
             }
             if(cnt == total)
                 flag = 2;
         }        
/*         for(j = 0; j < 3; j++)
        {
            printf("\n %d ��° ���� : ",j+1);
            for(temp = 1; temp <= stick[j][0]; temp++)
                printf("%d ",stick[j][temp]);
            printf("\n");
        }*/
         brama(ofp, n-1,c,b);
     }
}

void main()
{
    int T, n, i, j, temp;
    FILE *fp, *ofp;
        
    fp = fopen("B-small.in","r");
    ofp = fopen("result.txt","w+");
    
    fscanf(fp,"%d", &T);
    
    for(i = 0; i < T; i++)
    {
        fscanf(fp,"%d", &n);

        flag = 0;
        total = n;
        
        for(j = 0; j < total; j++)
            stick[j] = 1;

        //input second
        for(j = 0; j < n; j++)
        {
            fscanf(fp,"%d", &temp);
            second[j] = temp;
        }

        // input third
        for(j = 0; j < n; j++)
        {
            fscanf(fp,"%d", &temp);
            third[j] = temp;
        }
//        for(j = 0; j < 3; j++)
//            printf("%d, %d\n",second[j], third[j]);
        brama(ofp, n,1,2);
        
        if(flag == 2)
            fprintf(ofp,"1\n");
        else
            fprintf(ofp,"0\n");
            
/*        for(j = 0; j < 3; j++)
        {
            printf("\n %d ��° ���� : ",j+1);
            for(temp = 1; temp <= stick[j][0]; temp++)
                printf("%d ",stick[j][temp]);
            printf("\n");
        }
        printf("\n--------------------\n");*/
    }
    
    fclose(fp);
    fclose(ofp);
    system("PAUSE");	
}

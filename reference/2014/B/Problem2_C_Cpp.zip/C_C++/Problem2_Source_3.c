#define _CRT_SECURE_NO_WARNINGS

#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#define FALSE 0
#define TRUE 1

#define debugprint( __X__ )		//printf __X__

int tob_convertstatetobinary( int nNumOfDisks, int *panDisksState, char *pacBinaryState )
{
	int		nResult		= FALSE;
	int		nLoop		= 0;
	char	cPrevBin	= 0;
	char	cPrevPeg	= 0;

	if( nNumOfDisks && panDisksState && pacBinaryState )
	{
		for( nLoop = 0; nLoop < nNumOfDisks; ++nLoop )
		{
			if( !cPrevBin && !cPrevPeg )
			{
				cPrevBin = ( panDisksState[ nLoop ] == 2 ) ? '1' : '0';	
			}
			else
			{
				cPrevBin = ( panDisksState[ nLoop ] == cPrevPeg ) ? cPrevBin : ( 0x30 + !( cPrevBin - 0x30 ) );				
			}

			pacBinaryState[ nLoop ] = cPrevBin;
			cPrevPeg = panDisksState[ nLoop ];
		}

		nResult = TRUE;
	}

	return nResult;
}

int tob_isinitialstate( int nNumOfDisks, char *pacBinStates )
{
	int nResult = TRUE;
	int nLoop	= 0;

	if( nNumOfDisks && pacBinStates )
	{
		for( nLoop = 0; nLoop < nNumOfDisks; ++nLoop )
		{
			if( pacBinStates[ nLoop ] == '1' )
			{
				nResult = FALSE;
				break;
			}
		}
	}
	else
	{
		nResult = FALSE;
	}

	return nResult;
}

int tob_checkstates( int nNumOfDisks, int *panDisksState2Day, int *panDisksState3Day )
{
	int		nResult				= FALSE;
	char	*pac2DayBinState	= NULL;
	char	*pac3DayBinState	= NULL;

	if( nNumOfDisks && panDisksState2Day && panDisksState3Day )
	{
		if( ( pac2DayBinState = ( char * ) malloc( nNumOfDisks + 1 ) )
				&& ( pac3DayBinState = ( char * ) malloc( nNumOfDisks + 1 ) ) )
		{
			memset( pac2DayBinState, 0, nNumOfDisks + 1 );
			memset( pac3DayBinState, 0, nNumOfDisks + 1 );

			if( tob_convertstatetobinary( nNumOfDisks, panDisksState2Day, pac2DayBinState ) 
					&& tob_convertstatetobinary( nNumOfDisks, panDisksState3Day, pac3DayBinState ) )
			{
				if( !tob_isinitialstate( nNumOfDisks, pac2DayBinState ) 
						&& !tob_isinitialstate( nNumOfDisks, pac3DayBinState ) 
						&& strcmp( pac3DayBinState, pac2DayBinState ) > 0 )
				{
					nResult = TRUE;
				}
			}
		}

		if( pac2DayBinState )
		{
			free( pac2DayBinState );
			pac2DayBinState = NULL;
		}

		if( pac3DayBinState )
		{
			free( pac3DayBinState );
			pac3DayBinState = NULL;
		}
	}

	return nResult;
}

int main( int argc, char *argv[ ] )
{
	FILE		*fp					= NULL;
	int			nLoop				= 0;
	int			nNumOfTC			= 0;
	int			nBytesRead			= 0;
	int			nNumOfDisks			= 0;
	int			nPegNum				= 0;
	int			*panDisksState2Day	= NULL;
	int			*panDisksState3Day	= NULL;
	int			nTCLoop				= 0;
	int			nResult				= 0;
	
	if( argc < 2 )
	{
		printf("Invalid arguments\n");
		return 1;
	}

	fp = fopen( argv[1], "r" );

	if( NULL == fp )
	{
		printf("Invalid File\n");
		return 1;
	}

	nBytesRead = fscanf( fp, "%d", &nNumOfTC );
	debugprint(( "Total TC: %d\n", nNumOfTC ));

	if( nBytesRead && nNumOfTC )
	{
		for( nTCLoop = 0; nTCLoop < nNumOfTC; ++nTCLoop )
		{
			nBytesRead = fscanf( fp, "%d", &nNumOfDisks );
			debugprint(( "Number Of Disks: %d\n", nNumOfDisks ));

			if( nBytesRead && nNumOfDisks )
			{				
				if( ( panDisksState2Day = ( int * ) malloc( sizeof( int ) * nNumOfDisks ) )
						&& ( panDisksState3Day = ( int * ) malloc( sizeof( int ) * nNumOfDisks ) ) )

				{
					for( nLoop = 0; nLoop < nNumOfDisks; ++nLoop )
					{
						nBytesRead = fscanf( fp, "%d", &panDisksState2Day[ nLoop ] );
						debugprint(( "Initial State: push disk#%d on peg#%d\n", nNumOfDisks - nLoop, panDisksState2Day[ nLoop ] ));
					}				

					for( nLoop = 0; nLoop < nNumOfDisks; ++nLoop )
					{
						nBytesRead = fscanf( fp, "%d", &panDisksState3Day[ nLoop ] );
						debugprint(( "CurState: push disk#%d on peg#%d\n", nNumOfDisks - nLoop, panDisksState3Day[ nLoop ] ));
					}						

					nResult = tob_checkstates( nNumOfDisks, panDisksState2Day, panDisksState3Day );

					debugprint( ( "TC#%d result: %d\n", nTCLoop, nResult ) );
					printf( "%d\n", nResult );
				}

				if( panDisksState2Day )
				{
					free( panDisksState2Day );
					panDisksState2Day = NULL;
				}

				if( panDisksState3Day )
				{
					free( panDisksState3Day );
					panDisksState3Day = NULL;
				}
			}
		}
	}

	fclose( fp );

	return 0;
}

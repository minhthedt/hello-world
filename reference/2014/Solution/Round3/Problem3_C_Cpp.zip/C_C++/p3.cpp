#include <cstdio>
#include <cstring>
#include <iostream>

using namespace std;

int div[10] = {2, 3, 5, 7, 11, 13, 17, 19, 23, 29};
int arr[1111][1111];
long long temp[1111][1111];
long long temp_result[1111][1111];
long long result[1111][1111];
int n, m, k, l;

int main() {

  int tc;

  cin >> tc;
  while(tc--) {
    cin >> n >> m >> k >> l;

    memset(arr, 0, sizeof(arr));
    memset(temp, 0, sizeof(temp));
    memset(temp_result, 0, sizeof(temp_result));
    memset(result, 0, sizeof(result));

    for (int i = 0; i < m; i++) {
      int a, b;
      cin >> a >> b;
      arr[a][b]++;
      temp[a][b]++;
      result[a][b]++;
    }

    for (int len = 2; len <= l; len++) {
      memset(temp_result, 0, sizeof(temp_result));
      for (int i = 1; i <= n; i++) {
	for (int j = 1; j <= n; j++) {
	  for (int p = 1; p <= n; p++) {
	    if (i >= 2 && i <= k+1) {
	      temp_result[i][j] += (temp[i][p] * arr[p][j])%div[i-2];
	      temp_result[i][j] %= div[i-2];
	    } else {
	      temp_result[i][j] += (temp[i][p] * arr[p][j]);
	    }
	  }
	}
      }
      for(int i = 1; i <= n; i++) {
	for (int j = 1; j <= n; j++) {
	  if (i >= 2 && i <= k+1) {
	    result[i][j] = (result[i][j]%div[i-2] + temp_result[i][j]%div[i-2])%div[i-2];
	  } else {
	    result[i][j] += temp_result[i][j];
	  }
	  temp[i][j] = temp_result[i][j];
	}
      }
    }

    for (int i = 2; i <= k+1; i++) {
      result[i][1] %= div[i-2];
      cout << result[i][1] << " ";
    }
    cout << endl;

  }
  return 0;
}


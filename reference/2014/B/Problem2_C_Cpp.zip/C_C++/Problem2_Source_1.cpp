#include <iostream>
#include <fstream>

using namespace std;

bool Compare(int pNum , int lowBar , int highBar , int midBar, int *s1 , int *s2);
bool CheckValid(int pNum , int lowBar , int highBar , int midBar , int *s);
void IterateProcess(ifstream &fpin, ofstream &fpout);
void swap(int &a , int &b);

int main()
{
	ifstream fpin;
	ofstream fpout;

	int nrTc;

	fpin.open("input.txt");

	if(!fpin.is_open())
	{
		cout << " Fail to open file." << endl;
		return -1;
	}

	fpout.open("output.txt");

	fpin >> nrTc;

	for(int i = 0 ; i < nrTc ; i++)
	{
		IterateProcess(fpin, fpout);
	}
	return 0;
}

void IterateProcess(ifstream &fpin, ofstream &fpout)
{
	int nrCircleBar;
	fpin >> nrCircleBar;

	int *seq1 = new int [nrCircleBar];
	int *seq2 = new int [nrCircleBar];

	for(int i = 0 ; i < nrCircleBar ; i++)
	{
		fpin >> seq1[i];
	}
	for(int i = 0 ; i < nrCircleBar ; i++)
	{
		fpin >> seq2[i];
	}
	bool result = Compare(nrCircleBar , 1 , 2 , 3 , seq1 , seq2);

	fpout << result << endl;

	cout << result << endl;

	delete [] seq1;
	delete [] seq2;
}

bool Compare(int pNum , int lowBar , int highBar , int midBar, int *s1 , int *s2)
{
	while(pNum > 0)
	{
		if(*s1 == highBar && *s2 == lowBar)
		{
			return false;
		}
		if(*s1 == lowBar && *s2 == lowBar)
		{
			s1++;
			s2++;
			pNum--;
			swap(midBar , highBar);
		}
		else if(*s1 == highBar && *s2 == highBar)
		{
			s1++;
			s2++;
			pNum--;
			swap(lowBar , midBar);
		}
		else if(*s1 == lowBar && *s2 == highBar)
		{
			if(CheckValid(pNum -1 , lowBar , midBar , highBar , ++s1) && CheckValid(pNum -1 , midBar , highBar ,lowBar,  ++s2) )
			{
				return true;
			}
		}
		else
		{
			return false;
		}
	}

}

bool CheckValid(int pNum , int lowBar , int highBar , int midBar , int *s)
{
	while(pNum > 0)
	{
		if(*s == lowBar)
		{
			s++;
			pNum--;
			swap(midBar , highBar);
		}
		else if(*s == highBar)
		{
			s++;
			pNum--;
			swap(lowBar , midBar);
		}
		else
		{
			return false;
		}
	}
	return true;
}

void swap(int &a , int &b)
{
	int tmp;
	tmp = a;
	a = b;
	b = tmp;
}


#include <stdio.h>
#include <malloc.h>
int main()
{
	int index =0;//used for test cases index 
	int diskIndex; 
	int rodNumber1=0;
	int rodNumber2=0;
	int testcases;
	int numberOfDisks;
	int flag=0;
	int *tower[2];
	int temp_index=0;

FILE *t1 = fopen("B-small.in","r");
if(!t1)
	return -1; //file is not opened.

fscanf(t1,"%lu",&testcases);
if(feof(t1))
{
	fclose(t1);
	return -2;
}
for(;index<testcases;index++)
{

	fscanf(t1,"%lu",&numberOfDisks);

	tower[0] = ( int*)malloc(numberOfDisks*sizeof(int));
	tower[1] = (int*)malloc(numberOfDisks*sizeof(int));
	for(temp_index=0;temp_index<numberOfDisks;temp_index++)
	{
		fscanf(t1,"%d",&tower[0][temp_index]);
//		printf("%d\n",tower[0][temp_index]);
	}
	for(temp_index=0;temp_index<numberOfDisks;temp_index++)
	{
	fscanf(t1,"%d",&tower[1][temp_index]);
	}
	for(diskIndex=0;diskIndex<numberOfDisks;diskIndex++)
	{
//		printf("%d\n",diskIndex);
		if(tower[1][diskIndex] ==2)
		{
			if(tower[0][diskIndex] ==2)
			{
				continue;
			}
			else if(tower[0][diskIndex] < tower[1][diskIndex])
			{
				printf("1\n");
				break;
			}
			else
			{
				printf("0\n");
			}
		}
		else if(2 == tower[0][diskIndex])
		{
			if(tower[0][diskIndex]<tower[1][diskIndex])
			{
				printf("0\n");
				break;
			}
			else if(tower[0][diskIndex]>tower[1][diskIndex])
			{
				printf("1\n");
				break;
			}
			else
			{

			}
		}
		else if(tower[0][diskIndex]<tower[1][diskIndex])
		{
			printf("1\n");
			break;
		}
		else if(tower[0][diskIndex]>tower[1][diskIndex])
		{
			printf("0\n");
			break;
		}
		else
		{

		}
	}
}
fclose(t1);

return 0;
}


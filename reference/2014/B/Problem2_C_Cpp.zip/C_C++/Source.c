#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <Windows.h>

int *state[2];
int result = 0;

int N;

int brahma(int n, int from, int temp, int to);

void main()
{
	FILE *in, *out;
	int T;
	int i = 0, j = 0;

	//file I/O
	//if ((in = fopen("input.txt", "r")) == 0)
	//if ((in = fopen("B-small.in", "r")) == 0)
	if ((in = fopen("B-large.in", "r")) == 0)
	{
		printf("Input File error!!\n");
		return;
	}

	if ((out = fopen("output.txt", "w")) == 0)
	{
		printf("Output File error!!\n");
		return;
	}

	//Read Number of TestCase
	fscanf(in, "%d", &T);

	for (i = 0; i < T; i++)
	{
		fscanf(in, "%d", &N);
		state[0] = (int*)malloc(sizeof(int)*N);
		state[1] = (int*)malloc(sizeof(int)*N);

//		printf("\ntest T #%d\n", i);
//		printf("size : %d\n", N);

		//init state
		for (j = N-1; j > -1; j--)
		{
			fscanf(in, "%d", &state[0][j]);
		}
		for (j = N-1; j > -1; j--)
		{
			fscanf(in, "%d", &state[1][j]);
		}

		result = brahma(N, 1, 3, 2);

		if (result == 1)
			fprintf(out, "1\n");
		else
			fprintf(out, "0\n");

		free(state[0]);
		free(state[1]);
	}

	//free FD
	if (in != 0)
	{
		fclose(in);
	}

	if (in != 0)
	{
		fclose(out);
	}

	printf("End!!!\n");
	return;
}

int brahma(int n, int from, int temp, int to)
{
	int j,re;
	int down1, remain1, up1, t1, re1;
	int down2, remain2, up2, t2, re2;
	down1 = down2 = from;
	remain1 = remain2 = temp;
	up1 = up2 = to;
	re = -1;

	for (j = n - 1; j >= 0; j--)
	{
		if (state[0][j] == down1)
		{
			t1 = up1;
			up1 = remain1;
			remain1 = t1;
			re1 = 0;
		}
		else if (state[0][j] == up1)
		{
			t1 = down1;
			down1 = remain1;
			remain1 = t1;
			re1 = 1;
		}
		else
		{
			break;
		}

		if (state[1][j] == down2)
		{
			t2 = up2;
			up2 = remain2;
			remain2 = t2;
			re2 = 0;
		}
		else if (state[1][j] == up2)
		{
			t2 = down2;
			down2 = remain2;
			remain2 = t2;
			re2 = 1;
		}
		else
		{
			break;
		}

		if (re == -1)
		{
			if (re1 > re2)
			{
				re = 0;
			}
			else if(re1 < re2)
			{
				re = 1;
			}
		}
	}

	
	if (j == -1 && re == 1)
	{
		//printf("%d : OK\n", j);
		return 1;
	}
	else
	{
		//printf("%d : XXX\n", j);
		return 0;
	}
	
}

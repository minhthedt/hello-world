#include "stdio.h"
#include "string.h"
#include "memory.h"


int getindex (int i)
{
      switch (i)
      {
         case 0:
         {
            i=2;
         }
         break;
         case 1:
         {
            i=1;
         }
         break;

         case 2:
         {
            i=3;
         }
         break;

      }

      return i;
}

int getindex_odd(int i)
{
      switch (i)
      {
         case 0:
         {
            i=2;
         }
         break;
         case 1:
         {
            i=3;
         }
         break;

         case 2:
         {
            i=1;
         }
         break;

      }

      return i;
}


void printdisk (char *disk, int n)
{
   int i=0;

   for (i=0; i<n; ++i){
      printf ("%d ", disk[i]);
   }

   printf ("\n");
}
void main(void)
{
   int n=0, x, i, to, fr, tc=0, l1=0;
   char flag=0;
   char disk [100000] ={0}, s1[100000] = {0},s2[100000] = {0};

   scanf("%d\n", &tc);

   while (tc)
   {
      --tc;
      scanf("%d\n", &n);
      flag=0;
      l1=0;
      i=0;

      for (l1=0; l1<n; ++l1){
         scanf("%d\n", &s1[l1]);
      }


      for (l1=0; l1<n; ++l1){
         scanf("%d\n", &s2[l1]);
      }

      memset (disk, 2, n );
      if ( 0== flag){ 
         if ( 0 == memcmp (disk, s2, n)) {
            flag=1;
         }
      }
      for (x=1; x < (1 << n); x++) {
         i=x&x-1; to=(i+i/3)&3;
         i=(x|x-1)+1; fr=(i+i/3)&3;

        if (0 == n%2){
         to = getindex(to);
         fr = getindex(fr);
      }
      else{
          to = getindex_odd(to);
          fr = getindex_odd(fr);
      }


         for (l1=n-1; l1>=0; --l1){
             if ( to == disk[l1]){ 
               disk[l1]=fr;
	            break;
            }
         }

				if ( 0== flag){
					if ( 0 == memcmp (disk, s2, n)){
						flag=1;
					}

				}
				else	{
						if ( 0 == memcmp (disk, s1, n)){
							flag=2;
							printf ("1\n");
						}
				}
         }
      
      if (2 != flag){   
          printf ("0\n");
      }
   }
}



#include <stdio.h>
#include <vector>
#include <algorithm>
#include <vector>
#include <queue>
#include <iostream>
#include <fstream>
using namespace std;

vector<vector<int> >GRAPH(50000);
ofstream out("C-small.txt", std::ofstream::out | std::ofstream::app);
//ofstream outd("C-small-debug.txt", std::ofstream::out | std::ofstream::app);
	
int divi[10] = {2, 3, 5, 7, 11, 13, 17, 19, 23, 29};
int k,ind = 0 ;


bool isadjacency_node_not_present_in_current_path(int node,vector<int>path)
{
    for(int i=0;i<path.size();++i)
    {
        if(path[i]==node)
        return false;
    }
    return true;
}
long  findpaths(int source ,int target , int max_links, int count)
{
    vector<int>path;
    path.push_back(source);
    queue<vector<int> >q;
    q.push(path);

    while(!q.empty())
    {
        path=q.front();
        q.pop();
		
		k = path.size()-1;
        int last_nodeof_path=path[k];
        if(last_nodeof_path==target && k!=0 )
        {
			if ( k <= max_links)
			{
				count += 1;
			}
        }
		
		for(int i=0;i<GRAPH[last_nodeof_path].size();++i)
        {
            if(isadjacency_node_not_present_in_current_path(GRAPH[last_nodeof_path][i],path))
            {

                vector<int>new_path(path.begin(),path.end());
                new_path.push_back(GRAPH[last_nodeof_path][i]);
                q.push(new_path);
            }
        }
    }
    return count;
}

int main(int argc, char* argv[])
{

	FILE *fp;
	fp = fopen("e:\\codejam\\C-small.in", "r");
	
	char buffer[20];
	int b,c[100];
	
	int testcases, pages, links, max_start_points, max_links, temp_link1, temp_link2;
	int i=1,j,u,v ;
	//long int count = 0;
	
	fscanf(fp,"%d",&testcases);
	printf("%d\n",testcases);
	//testcases =1;
	while (i <=testcases)
	{
		cout<<"graph size"<<GRAPH.size()<<endl;
		fscanf(fp,"%d %d %d %d", &pages, &links, &max_start_points, &max_links);
		printf("%d %d %d %d\n", pages, links, max_start_points, max_links);
		for( j=1;j<=links;++j)
        {
         	fscanf(fp,"%d %d", &u, &v);
         	//outd<<"edges "<<u<<" "<<v<<endl;
            GRAPH[u].push_back(v);
        }
		int temp_max_links = max_links;
		for (int k =1;k<=max_start_points; k++)
		{
			max_links = temp_max_links;
			long ways = findpaths(k+1, 1, max_links,0); 
			ways = ways % divi[ind];
			out<<ways<<" ";
			++ind;
			//count = 0;	
		}
	++i;
	ind = 0;
	out<<std::endl;
	GRAPH.clear();
	GRAPH.resize(50000);
	}
	
	fclose(fp);
	out.close();
	//outd.close();
	//getchar();
return 0;
}


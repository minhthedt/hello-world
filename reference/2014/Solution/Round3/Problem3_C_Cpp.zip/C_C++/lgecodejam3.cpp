#include <stdio.h>
#include <stdlib.h>
#include <iostream>
#include <vector>
#include <hash_map>
#include <string>
#include <algorithm>
#include <time.h>

FILE* inputfp = stdin;
FILE* outputfp = stdout;

#define DATAINPUT(...) fscanf(inputfp, __VA_ARGS__)
#define RESULTOUTPUT(...) fprintf(outputfp, __VA_ARGS__)

using namespace std;
//using namespace stdext;

int process3();

int main(int argc, char* argv[])
{
//    int starttime = clock();
//    printf("start\n");
//    inputfp = fopen("C-large.in", "r+t");
//    outputfp = fopen("result.txt", "w+t");

	int totalcases;
	DATAINPUT("%d",&totalcases);
    while(totalcases)
    {
        process3();
        --totalcases;
    }

//    fclose(outputfp);
//    fclose(inputfp);
//    int endtime = clock();
//    printf("runtime %d\n", endtime - starttime);

    return 0;
}

class page
{
public:
    page() 
    {
        pos = 0;
        links = (int* )malloc(sizeof(int) * 10000);
        sames = (int* )malloc(sizeof(int) * 10000);
    }

    ~page()
    {
        free(links);
        free(sames);
    }

    void insert(int link)
    {
        int i = 0;
        for(i = 0; i < pos; i++)
        {
            if(links[i] == link)
                break;
        }

        if (i == pos)
        {
            links[i] = link;
            sames[i] = 1;
            pos++;
        }
        else
            sames[i] += 1;
            
//        links.push_back(link);
    }
    
    int size()
    {
        return pos;
    }

    int pos;
    int* links;
    int* sames;

//    vector<int> links;
};

inline int calcroute(page* pages, int startpage, int limit)
{
    int totalroute = 0;
    if(startpage == 1)
        ++totalroute;

    if(!limit)
        return totalroute;

//    int linknum = pages[startpage].links.size();
    int linknum = pages[startpage].size();
    while(linknum)
    {
        linknum--;
        totalroute += pages[startpage].sames[linknum] * calcroute(pages, pages[startpage].links[linknum], limit - 1);
    }

    return totalroute;
}

int process3()
{
    int pagenum, linknum, startnum, limit;
	DATAINPUT("%d %d %d %d",&pagenum, &linknum, &startnum, &limit);

    page* pages = new page[pagenum + 1];

    int start, end;
    while(linknum)
    {
   	    DATAINPUT("%d %d",&start, &end);
        pages[start].insert(end);
        --linknum;
    }

    int rm[10] = { 2, 3, 5, 7, 11, 13, 17, 19, 23, 29 }; 
    int i = 0;
    for(i = 0; i < startnum; i++)
    {
//        if (i)
//            RESULTOUTPUT(" ");
//        int result = calcroute(pages, i + 2, limit);
        RESULTOUTPUT("%d ", calcroute(pages, i + 2, limit) % (rm[i]) );
    }

    RESULTOUTPUT("\n");

    delete [] pages;

    return 0;
}

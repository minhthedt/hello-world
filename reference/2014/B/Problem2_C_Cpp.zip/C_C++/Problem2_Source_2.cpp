// �����_MC_Problem2_Source.cpp : �ܼ� ���� ���α׷��� ���� �������� �����մϴ�.
//

#include "stdafx.h"
#include <array>
#include <iostream>
#include <fstream>
#include <stack>
using namespace std;


int cnt = 0;


void hanoi(int n, int a, int b, array<stack<int>, 3> &current, array<array<stack<int>, 3>, 2> &diff, int &nC)
{

	int temp;
	if (n == 1)
	{
		current[b - 1].push(current[a - 1].top());
		current[a - 1].pop();
		if (current == diff[nC])
			nC++;
	}
	else
	{
		temp = 6 - a - b;
		hanoi(n - 1, a, temp, current, diff, nC);
		current[b - 1].push(current[a - 1].top());
		current[a - 1].pop();
		if (current == diff[nC])
			nC++;
		hanoi(n - 1, temp, b, current, diff, nC);
	}
}

bool Check(int N, array<array<stack<int>, 3>, 2> &a)
{
	array<stack<int>, 3> ra;
	stack<int> rs;
	ra[1] = rs;
	ra[2] = rs;
	for (int i = N; i > 0; i--) {
		rs.push(i);
	}
	ra[0] = rs;
	int nC = 0;
	hanoi(N, 1, 2, ra, a, nC);
	return nC == 2;
}

void ReadAndRun(ifstream &inputfile)
{
	int N, n, pos;

	array<array<stack<int>, 3>, 2> a;
	array<stack<int>, 3> b;
	array<stack<int>, 3> c;
	inputfile >> N;
	n = N;
	while (n) {
		inputfile >> pos;
		b[pos - 1].push(n);
		n--;
	}
	a[0] = b;

	n = N;
	while (n) {
		inputfile >> pos;
		c[pos - 1].push(n);
		n--;
	}
	a[1] = c;
	if (Check(N, a)) {
		cout << "1" << endl;
	}
	else 
		cout << "0" << endl;
}



int _tmain(int argc, _TCHAR* argv[])
{
	int n;

	ifstream inputfile;
	int T;
	inputfile.open("C:\\Users\\Yangil\\Downloads\\B-small.in"/*argv[0]*/);
	inputfile >> T;
	while (T--) {
		ReadAndRun(inputfile);
	};

	return 0;
}

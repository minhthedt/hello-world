#include <stdio.h>
#include <stdlib.h>
#include <vector>
#include <algorithm>

typedef long long           I64;
typedef unsigned long long  UI64;

using namespace std;

int gN, gM, gK, gL;

struct PageT
{
    int start;
    int count;
};

struct LinkT
{
    int from;
    int to;
    int count;

    bool operator <(const LinkT& r) const
    {
        if (from < r.from)
            return true;
        else if (from > r.from)
            return false;
        else
            return to < r.to;
    }
};

PageT gPages[1100];
LinkT gLinks[11000];

int gDivisor[] = { 1, 1, 2, 3, 5, 7, 11, 13, 17, 19, 23, 29 };

#define C_N 1100
#define C_L 11000
I64 (*gCache)[C_L];

I64 countPathExact(int start, int len)
{
    if (len < 0)
    {
        return 0ll;
    }

    if (len == 0)
        return I64(start == 1);

    if (gCache[start][len] >= 0ll)
        return gCache[start][len];

    I64 res = 0ll;

    int i = gPages[start].start;
    int e = i + gPages[start].count;
    for (; i < e; i++)
    {
        res += countPathExact(gLinks[i].to, len - 1) * gLinks[i].count;

// for debug
        if (res < 0)
            printf("error!\n");
    }

    return gCache[start][len] = res;
}

int countPath(int start, int len, int divisor)
{
    I64 res = 0ll;

    for (int i = 1; i <= len; i++)
    {
        res += countPathExact(start, i);

// for debug
        if (res < 0)
            printf("error!\n");
    }

    return (int)(res % divisor);
}

void process(FILE* pfIn, FILE* pfOut)
{
    int i, j, k, count;
    
    gCache = new I64[C_N][C_L];

    fscanf(pfIn, "%d", &count);
    for (i = 0; i < count; i++)
    {
        fscanf(pfIn, "%d %d %d %d", &gN, &gM, &gK, &gL);
        for (j = 0; j < gM; j++)
            fscanf(pfIn, "%d %d", &gLinks[j].from, &gLinks[j].to);

        sort(gLinks, gLinks + gM);
        k = 0;
        gLinks[k].count = 1;
        for (j = 1; j < gM; j++)
        {
            if (gLinks[k].from == gLinks[j].from
                && gLinks[k].to == gLinks[j].to)
                gLinks[k].count++;
            else
            {
                if (++k != j)
                {
                    gLinks[k].from = gLinks[j].from;
                    gLinks[k].to   = gLinks[j].to;
                }
                gLinks[k].count = 1;
            }
        }
        gM = k + 1;

        memset(gPages, 0, sizeof(gPages));
        int f = gLinks[0].from;
        gPages[f].start = 0;
        gPages[f].count = 1;
        for (j = 1; j < gM; j++)
        {
            if (f == gLinks[j].from)
                gPages[f].count++;
            else
            {
                f = gLinks[j].from;
                gPages[f].start = j;
                gPages[f].count = 1;
            }
        }

        gK++;

        memset(gCache, 0xFF, sizeof(gCache[0][0]) * C_N * C_L);

        for (j = 2; j <= gK; j++)
            fprintf(pfOut, "%d ", countPath(j, gL, gDivisor[j]));
        fprintf(pfOut, "\n");
    }

    delete[] gCache;
}

//-----------------------------------------------------------------------------

void process(const char* pcszInFile, const char* pcszOutFile)
{
    FILE* pfIn = fopen(pcszInFile, "rt");
    if (pfIn == NULL)
    {
        printf("file not found! \"%s\"\n", pcszInFile);
        exit(-2);
    }

    FILE* pfOut = fopen(pcszOutFile, "wt");
    if (pfOut == NULL)
    {
        printf("can't create file! \"%s\"\n", pcszOutFile);
        exit(-3);
    }

    process(pfIn, pfOut);

    fclose(pfIn);
    fclose(pfOut);
}

void main(int argc, char* argv[])
{
    if (argc != 3)
    {
        printf("Usage : %s <input_file> <output_file>\n", argv[0]);
        exit(-1);
    }

    process(argv[1], argv[2]);
}

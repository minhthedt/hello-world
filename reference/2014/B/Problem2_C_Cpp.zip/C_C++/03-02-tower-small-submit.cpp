//lgecodejam
//2014 - 03 - problem 2
//woojun.jung@lge.com
#include <stdio.h>
#include <iostream>
#include <map>
#include <string.h>

using namespace std;
int *state = NULL;
int *day2 = NULL;
int *day3 = NULL;
 
int size = 0;
int checkerIndex = 0;

void initState(int *data,int size) {
    if (NULL == data) return;
    for (int i=0; i< size ; i++) {
        data[i] = 1;
    }
    checkerIndex = 0;
}
void printState() {
    if (NULL == state) return;
    for (int i=0; i< size ; i++) {
        printf("%d:%d\n",i,state[i]);
    }
}
void checkState() {
    int *checker = NULL;
    if (0 == checkerIndex)
        checker = day2;
    else if (1 == checkerIndex)
        checker = day3;

    if (checker == NULL) return;

    for (int i=0; i< size ; i++) {
        if (checker[i] != state[i])
            return;
    }
    checkerIndex++;
    return;
}
void hanoi(int n, int a, int b)
{
    if (1 < checkerIndex) return;
    int temp;
    if(n==1)
    {
        state[size-n] = b;
        checkState();
    }
    else
    {
        temp=6-a-b; 
        hanoi(n-1, a, temp);
        state[size-n] = b;
        checkState();
        hanoi(n-1, temp, b);
    }
}

int main()
{
    int T;
    scanf("%d", &T);
    int n;
    int temp;
    int i, j;

    for (i=0; i<T; i++) {
        scanf("%d", &n);//disk number
        state = new int [n];
        size = n;
        day2 = new int [n];
        day3 = new int [n];
        initState(state, n);
        memset(day2, 0, n);
        memset(day3, 0, n);
        //day2
        for (j=0;j<n;j++) {
            scanf("%d",&temp);
            day2[j] = temp;
        }
        //day3
        for (j=0;j<n;j++) {
            scanf("%d",&temp);
            day3[j] = temp;
        }
        hanoi(n, 1, 2);
        if (checkerIndex == 2) printf("1\n");//success
        else printf("0\n");//fail
        delete [] state;
        delete [] day2;
        delete [] day3;

    }
    return 0;

}



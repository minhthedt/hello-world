#include <stdio.h>
#include <stdlib.h>
#include <memory.h>

#define MAX_N		1001
#define LCM			6469693230		// LCM of (2, 3, 5, 7, 11, 13, 17, 19, 23, 29)

typedef struct {
	int count;
	int* links;
	int space;
	long long int *paths;
} page_t;

page_t g_pages[MAX_N];

void init_pages(int max_pages, int max_dist)
{
	int i;
	for (i = 1; i <= max_pages; i++)
	{
		page_t *p = &g_pages[i];
		p->count = 0;
		p->links = 0;
		p->space = 0;

		p->paths = (long long int *)malloc(sizeof(long long int) * (max_dist + 1));
		memset(p->paths, 0, sizeof(long long int) * (max_dist + 1));
	}
}

void free_pages(void)
{
	int i;
	for (i = 1; i < MAX_N; i++)
	{
		page_t *p = &g_pages[i];
		p->count = 0;
		p->space = 0;
		if (p->links)
		{
			free(p->links);
			p->links = 0;
		}
		if (p->paths)
		{
			free(p->paths);
			p->paths = 0;
		}
	}
}

void ensure_space(int n)
{
	const int initial_size = 64;
	page_t *p = &g_pages[n];

	if (p->space == 0)
	{
		p->space = initial_size;
		p->links = (int *)malloc(sizeof(int) * initial_size);
		memset(p->links, 0, sizeof(int) * initial_size);
	}
	else if (p->space <= p->count)
	{
		int *p_new = (int *)malloc(sizeof(int) * p->space * 2);
		memset(p_new, 0, sizeof(int) * p->space * 2);
		memcpy(p_new, p->links, sizeof(int) * p->space);
		free(p->links);

		p->links = p_new;
		p->space *= 2;
	}
}

void fill_page_paths(int max_n, int pnum, int dist)
{
	page_t *p, *pp;
	int i;

	if (dist == 1)
	{
		p = &g_pages[pnum];
		for (i = 0; i < p->count; i++)
		{
			if (p->links[i] == 1)
			{
				p->paths[1]++;
			}
		}
	}
	else
	{
		p = &g_pages[pnum];
		for (i = 0; i < p->count; i++)
		{
			pp = &g_pages[p->links[i]];
			p->paths[dist] += pp->paths[dist - 1];
			p->paths[dist] %= LCM;
		}
	}
}

int main(int argc, const char* argv[])
{
	FILE *fin = NULL;
	FILE *fout = NULL;
	const char *fin_name = "..\\C-large.in";
	const char *fout_name = "CON";

	int test_set;
	int t, i, d;
	int n, m, k, l;
	int from, to;
	page_t *pp;
	long long int result;
	const int result_div[] = {2, 3, 5, 7, 11, 13, 17, 19, 23, 29 };

	if (argc >= 2)
		fin_name = argv[1];
	if ((fin = fopen(fin_name, "rt")) == NULL)
	{
		return 0;
	}

	if (argc >= 3)
		fout_name = argv[2];
	if ((fout = fopen(fout_name, "wt")) == NULL)
	{
		fclose(fin);
		return 0;
	}

	memset(g_pages, 0, sizeof(g_pages));

	fscanf(fin, "%d", &test_set);

	for (t = 0; t < test_set; t++)
	{
		fscanf(fin, "%d %d %d %d", &n, &m, &k, &l);
		init_pages(n, l);

		for (i = 0; i < m; i++)
		{
			fscanf(fin, "%d %d", &from, &to);

			pp = &g_pages[from];
			ensure_space(from);
			pp->links[pp->count] = to;
			pp->count++;
		}

		for (d = 1; d <= l; d++)
		{
			for (i = 1; i <= n; i++)
			{
				fill_page_paths(n, i, d);
			}
		}

		for (i = 2; i <= k + 1; i++)
		{
			if (g_pages[i].paths)
			{
				result = 0;
				for (d = 1; d <= l; d++)
				{
					result += g_pages[i].paths[d];
					result %= result_div[i - 2];
				}

				fprintf(fout, "%d ", result);
			}
			else
			{
				fprintf(fout, "0 ");
			}
		}

		fprintf(fout, "\n");
		free_pages();
	}

	fclose(fin);
	fclose(fout);
	return 0;
}

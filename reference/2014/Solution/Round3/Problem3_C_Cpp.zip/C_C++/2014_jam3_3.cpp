// 2014_jam3_3.cpp : �ܼ� ���� ���α׷��� ���� �������� �����մϴ�.
//

#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#define SIZE 1001


	int T = 0;
	int N = 0;
	int M = 0;
	int K = 0;
	int L = 0;

void print(int *tmp)
{
	printf("answer : ");
	for(int i = 1; i <= N; i++)
	{
		printf("%d ", tmp[i]);
	}
	printf("(answer)\n");
}

int main(void)
{
	FILE *fp;
	FILE *afp;

	int *node[SIZE];
	int answer[SIZE];
	int answer_tmp[2][SIZE];
	int div[12] = {1,1,2,3,5,7,11,13,17,19,23,29};

	for(int i = 0; i < SIZE; i++)
		node[i] = (int*)malloc(sizeof(int)*SIZE);

	fp = fopen("test.txt", "r");
	afp = fopen("answer3", "w");
	fscanf(fp, "%d", &T);

	while(T-- > 0)
	{
		for(int i = 0; i < SIZE; i++)
			memset(node[i], 0, sizeof(int)*SIZE);
		memset(answer, 0, sizeof(answer));

		fscanf(fp, "%d %d %d %d", &N, &M, &K, &L);
		for(int i = 0; i < M; i++)
		{
			int from, to;
			fscanf(fp, "%d %d", &from, &to);
			node[from][to]++;
		}
		/*for(int i = 1; i < N; i++){
			printf("[%2d] ", i);
			for(int j = 1; j < N; j++)
				printf("%d ", node[i][j]);
			printf("\n");
		}*/
		for(int k = 2; k <= K+1; k++)
		{
			for(int i = 0; i <= N; i++){
				answer[i] = node[k][i];
				answer_tmp[0][i] = answer[i];
			}
			//printf("answer_tmp0 :");
			//print(answer_tmp[0]);
			for(int l = 1; l < L; l++)
			{
				memset(answer_tmp[l%2], 0, sizeof(int)*SIZE);
				for(int i = 1; i <= N;i++){
					if(answer_tmp[(l+1)%2][i] > 0)
					{
						for(int j = 0; j <= N; j++)
						{
							if(node[i][j] > 0)
								answer_tmp[l%2][j] += ((answer_tmp[(l+1)%2][i]%div[k]) * (node[i][j]%div[k]));
						}
					}
				}
				for(int i = 1; i <= N;i++)
					answer[i] += answer_tmp[l%2][i]%div[k];
				//printf("answer :");
				//print(answer);
				//printf("answer_tmp[%d] :", l%2);
				//print(answer_tmp[l%2]);
			}
			//print(answer);
			//printf("k(%d div=%d) answer : %d\n", k, div[k], answer[1]%div[k]);
			printf("%d ", answer[1]%div[k]);
			fprintf(afp, "%d ", answer[1]%div[k]);
		}
		fprintf(afp, "\n");
		printf("\n");
	}
	fclose(afp);
	return 0;
}


/*
 * andrey.fedorov@lge.com
 * problem 3 source code
 * to compile g++ 3.cpp -std=c++11 -O3
 * to run ./a.out <in-file>
 * results will be in res.out
*/


#include <stdio.h>
#include <stdint.h>
#include <vector>

using namespace std;

#define N 1000	

typedef vector<int> vecint;

int64_t ind(int from, int to){
	return N*from + to;
}

void dumpres(vector<vecint>& res){
	for( auto i: res){
		for(auto j: i) fprintf(stderr, "%d ->", j);
		fprintf(stderr, "\n");
	}
	fprintf(stderr, "\n");
}

int calcRes(vector<vecint>& paths, int* g, int searchnode){
	int rem[] = {0,0,2, 3, 5, 7, 11, 13, 17, 19, 23, 29};
	int Rem = rem[searchnode];
	int64_t sum = 0;

//	fprintf(stderr, "Rem is %d\n", Rem);
	for( auto i: paths){
		int prev = 0;
		int64_t mul = 1;
		for(auto j: i){
		       	if(prev) {
				mul*= g[ ind(j,prev) ];	
			}
			prev = j;
		}
//		fprintf(stderr, "mul %lld\n", mul);
		sum+=mul;
	}
//		fprintf(stderr, "sum %lld\n", sum);

	return sum % Rem;
}

void searchPath(vecint* parent, int start, int node, int depth, vecint& stack, vector<vecint>& res){

	stack.push_back(start);
	if( start == node ) { 
/*		fprintf(stderr, "res: ");
		for(auto i: *stack) fprintf(stderr, "%d->", i);
		fprintf(stderr, "\n");
*/		res.push_back(stack);
	}

	if(depth){
		for( auto j : parent[start] ){
			searchPath(parent, j, node, depth - 1, stack, res);
		}
	}
	stack.pop_back();
}

void solveTest(FILE* in, FILE* out){

	char buf[256];
	int npages, mlinks, kstarts, len, i;
	int from, to;
	int g[N*N];
	vecint parent[N], child[N];

	if( !fgets(buf,256,in) ) {fprintf(stderr, "2: Cannot read\n"); }
	sscanf(buf,"%d %d %d %d", &npages, &mlinks, &kstarts, &len);


	for(int64_t ii=0; ii<N*N ; ii++ ) g[ii]=0;

	for(i=0; i<mlinks; i++){
		if( !fgets(buf,256,in) ) {fprintf(stderr, "2: Cannot read\n"); }
		sscanf(buf,"%d %d", &from, &to);
//		fprintf(stderr,"%d -> %d\n", from, to);

		if( !g[ ind(from,to) ] ){
			parent[to].push_back(from);
//			fprintf(stderr,"%d P-> %d\n", from, to);
		}

		if( !g[ ind(from,to) ] ){
//			fprintf(stderr,"%d C-> %d\n", from, to);
			child[from].push_back(to);
		}

		g[ ind(from,to) ] ++;
		
	}
/*
	for( i=1; i<npages+1; i++){
		fprintf(stderr, "p %d:", i);

		for(auto j:parent[i]){
			fprintf(stderr, " %d", j);
		}

		fprintf(stderr, "\n");
		fprintf(stderr, "c %d:", i);

		for(auto j:child[i]){
			fprintf(stderr, " %d", j);
		}

		fprintf(stderr, "\n");
	}
*/

	for(int searchnode = 2; searchnode < kstarts + 2 ; searchnode++){
		vecint stack;
		vector<vecint> paths;
		int res;
		searchPath(parent, 1, searchnode, len, stack, paths);
	//	dumpres(paths);
		res = calcRes(paths, g, searchnode);
		fprintf(out,"%d ", res);
	}
	fprintf(out,"\n");

}

int main(int argc, char* argv[]){
	FILE* f, *fout;
	char* file;
	char buf[256];
	int ntests, solution, i;

	if( argc != 2) { fprintf(stderr, "Specify input file\n"); return 0; }
	file = argv[1];
	fprintf(stderr, "Opening %s\n", file);
	f = fopen(file,"r");
	if( !f ) {fprintf(stderr, "Cannot open %s\n", file); }
	if( !fgets(buf,256,f) ) {fprintf(stderr, "1: Cannot read %s\n", file); }

	sscanf(buf,"%d", &ntests);
	fprintf(stderr, "Number of tests is %d\n", ntests);
	fout = fopen("res.out", "w");

	for(i = 0; i<ntests; i++) {
 		fprintf(stderr, "New task %d\n", i);
		solveTest(f, fout);
	}

	return 0;
}



/*
 ============================================================================
 Name        : Problem2.c
 Copyright   : Copyright(c) 2014 by LG Electronics Inc.
 ============================================================================
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

//#define DEBUG
#define ARRAY(A, p, i) A[p*N+i]

static void print_pole_data(int N, int *pole, int *num) {
    for (int p = 1; p <= 3 ; p++) {
        fprintf(stderr, "p%d: ", p);
        for (int i = 1; i <= num[p] ; i++) {
            fprintf(stderr, "%2d ", ARRAY(pole, p, i));
        }
        fprintf(stderr, "\n");
    }
}

static void read_pole_data(int N, int *is_min, int *count) {

#ifdef DEBUG
    int *pole = (int*)malloc(sizeof(int)*(3+1)*(N+1));
    int *num = (int*)malloc(sizeof(int)*(3+1));

    for (int p = 1; p <= 3; p++)
        num[p] = 0;
#endif

    int state[3+1] = {0, 1, 1, 1};
    int old_p=1, buf_p, moved=1;
    *is_min = 1;

    for (int i = N; i >= 1; i--) {
        unsigned int p = 0;
        if (fscanf(stdin, "%u", &p) <= 0 || p > 3) {
            fputs("invalid data\n", stderr);
            exit(EXIT_FAILURE);
        }

        if (old_p == p) {
            state[p]++;
            count[i] = 0;
        } else {
            buf_p = 6 - old_p - p;
            if ((state[old_p] % 2) == 0) {
                if (state[p] == 0) {
#ifdef DEBUG
                    fprintf(stderr, "is not min: %d\n", i);
#endif
                    *is_min = 0;
                }
            } else {
                if (state[buf_p] == 0) {
#ifdef DEBUG
                    fprintf(stderr, "is not min: %d\n", i);
#endif
                    *is_min = 0;
                }
            }
            state[p] = 1;
            state[buf_p] = 0;

            count[i] = moved;
            moved = (moved == 1) ? -1 : 1;
        }

#ifdef DEBUG
        num[p]++;
        ARRAY(pole, p, num[p]) = i;
#endif

        old_p = p;
    }

#ifdef DEBUG
    print_pole_data(N, pole, num);
    free(pole);
    free(num);
#endif
}

static int compare_count(int N, int *count1, int *count2) {
    for (int i=N; i >= 1 ; i--) {
        int cmp = count1[i] - count2[i];
        if (cmp != 0)
            return cmp;
    }
    return 0;
}

static void print_count(int N, int *count) {
    for (int i=N; i >= 1 ; i--) {
        fprintf(stderr, "%2d ", count[i]);
    }
    fprintf(stderr, "\n");
}

int main(void) {

    unsigned int T = 0;

	if (fscanf(stdin, "%u", &T) <= 0) {
		fputs("invalid input!\n", stderr);
        fprintf(stdout, "T=%d\n", T);
		exit(EXIT_FAILURE);
	}
#ifdef DEBUG
    fprintf(stderr, "T=%d\n", T);
#endif

    while (T-- > 0) {
        unsigned int N = 0;

        if (fscanf(stdin, "%u", &N) <= 0 || !(N >= 2 && N <= 100000)) {
            fputs("invalid input! 2\n", stderr);
            exit(EXIT_FAILURE);
        }
#ifdef DEBUG
        fprintf(stderr, "N=%d\n", N);
#endif

        int d2_is_min, d3_is_min;

        int *d2_count = (int*)malloc(sizeof(int)*(N+1));
        int *d3_count = (int*)malloc(sizeof(int)*(N+1));

        read_pole_data(N, &d2_is_min, d2_count);
        read_pole_data(N, &d3_is_min, d3_count);

        if ((d2_is_min * d3_is_min) == 0) {
#ifdef DEBUG
            fprintf(stderr, "is not min_move %d %d\n", d2_is_min, d3_is_min);
#endif
            fprintf(stdout, "%d\n", 0);
        } else {
            int *d1_count = (int*)malloc(sizeof(int)*(N+1));
            memset(d1_count, 0x00, sizeof(int)*(N+1));

            if (compare_count(N, d1_count, d2_count) >= 0
                || compare_count(N, d2_count, d3_count) >= 0
               ) {
#ifdef DEBUG
                fprintf(stderr, "wrong count\n");
                print_count(N, d1_count);
                print_count(N, d2_count);
                print_count(N, d3_count);
#endif
                fprintf(stdout, "%d\n", 0);
            } else {
                fprintf(stdout, "%d\n", 1);
            }

            free(d1_count);
        }

        free(d2_count);
        free(d3_count);
    }
    return EXIT_SUCCESS;
}


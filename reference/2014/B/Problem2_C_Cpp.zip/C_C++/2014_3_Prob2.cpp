// 2014_3_Prob2.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include <stdio.h>
#include <stdlib.h>
#include <memory.h>

int _tmain(int argc, _TCHAR* argv[])
{
	FILE *fp, *fpout;
	fp = fopen(argv[1], "r");
	fpout = fopen("out.txt", "w");
	if(NULL == fp) return 0;
	
	int T, N;
	int a[2],b[2],result;
	int *num[2];
	int diff;
	int reverse;

	fscanf(fp, "%d", &T);

	for(int t=0; t<T; t++)
	{
		fscanf(fp, "%d", &N);

		num[0] = (int *)malloc(sizeof(int) * N);
		num[1] = (int *)malloc(sizeof(int) * N);
		
		for(int n=0; n<N; n++)
		{
			fscanf(fp, "%d", &num[0][n]);
		}

		for(int n=0; n<N; n++)
		{
			fscanf(fp, "%d", &num[1][n]);
		}

		a[0] = a[1] = 1;
		b[0] = b[1] = 2;
		diff = 0;
		reverse = 0;
		result = 1;

		for(int n=0; n<N; n++)
		{
			if(reverse == 0) {
				if(num[0][n] == a[0] && num[1][n] == b[1])
					reverse = -1;
				else if(num[0][n] == b[0] && num[1][n] == a[1]) {
					reverse = 1;
					result = 0;
					break;
				}
			}

			if(num[0][n] == a[0]) {
				b[0] = 6-a[0]-b[0];
			} else if(num[0][n] == b[0]) {
				a[0] = 6-a[0]-b[0];
				diff = 1;
			} else {
				result = 0;
				break;
			}

			if(num[1][n] == a[1]) {
				b[1] = 6-a[1]-b[1];
			} else if(num[1][n] == b[1]) {
				a[1] = 6-a[1]-b[1];
			} else {
				result = 0;
				break;
			}
		}

		if(diff == 0) result = 0;

		fprintf(fpout,"%d\n", result);

		free(num[0]);
		free(num[1]);
	}

	fclose(fp);
	fclose(fpout);

	return 0;
}


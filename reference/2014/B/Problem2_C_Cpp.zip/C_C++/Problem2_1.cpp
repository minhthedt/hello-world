#include <iostream>
#include <string.h> // memset()
#include <stdlib.h> // exit(), abs()
#include <string>
#include <algorithm> // min(), max(), sort(), is_sorted(), reverse()
#include <vector> // vector
#include <utility>
#include <fstream>
#include <queue> // queue

using namespace std;

// #define DEBUG
#define swap(a, b, temp) {(temp)=(a);(a)=(b);(b)=(temp);}
#define push(e)   (stack[++top]=(e))
#define pop()     (stack[top--])
#define peek()    (stack[top])
#define delete()  (top--)
#define isEmptyStack() (top<0)
#define SIZE_STACK 1024
static int stack[SIZE_STACK] = { 0 };
static int top;

static fstream gFS;
static const int RODCNT = 3;

typedef unsigned long long uint64;

struct testCase
{
	int mDiskCnt;
	uint64 mSecond;
	uint64 mThird;
	uint64 mState;
	int mFinalCount;
	int mMoveCnt;	
	void readData();
	void initData(uint64& start, uint64& end);
	void printResult();
	uint64 getVal(uint64 state, int index) { 
		if (index * 2 >= 32) { state >>= 32; state >>= (index * 2 - 32); state &= 0x03; return state; }
		else return ((state >> (index * 2)) & 0x03); 
     }
	uint64 setVal(uint64 state, int index, int value) { 
		uint64 tmp = value;
		if (index * 2 >= 32) {			
			tmp <<= 32; tmp <<= (index * 2 - 32);
			return ((state & ~(3LLU << (index * 2))) | (tmp));
		}
		else  return ((state & ~(3LLU << (index * 2))) | (tmp << (index * 2)));
	}	
	bool hanoiSearach(int disks, int from, int by, int to);
	void move(int disk, int from, int to);
	bool mPass1, mPass2;
};

void testCase::readData()
{
	gFS >> mDiskCnt;

	mSecond = mThird = 0ULL;
	int rod;
	
	for (int i = mDiskCnt - 1; i >= 0; --i) {
		gFS >> rod;		
		mSecond = setVal(mSecond, i, rod);	
	}

	for (int i = mDiskCnt - 1; i >= 0; --i) {
		gFS >> rod;
		mThird = setVal(mThird, i, rod);	
	}		
}

void testCase::move(int disk, int from, int to)
{	
	mMoveCnt++;
	
	mState = setVal(mState, disk-1, to);
	
	if (!mPass1 && mState == mSecond) { 
		mFinalCount++; 
		mPass1 = true;
#ifdef DEBUG
		cout << "Disk(" << disk << "), " << "From : " << from << ", To : " << to << endl;
		for (int i = mDiskCnt - 1; i >= 0; --i)
			cout << "Disk(" << i+1 << ") : " << getVal(mState, i) << endl;
#endif		
	}

	if (!mPass2 && mState == mThird) { 
		if (mFinalCount >= 0) {
			mFinalCount++;
			mPass2 = true;
#ifdef DEBUG
			cout << "Disk(" << disk << "), " << "From : " << from << ", To : " << to << endl;
			for (int i = mDiskCnt - 1; i >= 0; --i)
				cout << "Disk(" << i+1 << ") : " << getVal(mState, i) << endl;
#endif			
		}
	}
}

void testCase::initData(uint64& start, uint64& end)
{
	start = end = 0;
	for (int i = mDiskCnt - 1; i >= 0; --i) {
		start = setVal(start, i, 1);		
	}

	for (int i = mDiskCnt - 1; i >= 0; --i) {
		end = setVal(end, i, 2);
	}

	mMoveCnt = 0;
	mState = start;
	mFinalCount = -1;	
	mPass1 = mPass2 = false;
}

bool testCase::hanoiSearach(int disks, int from, int by, int to)
{
	int complete = 0;
	int temp = 0;
	top = -1;

	uint64 start, end;
	initData(start, end);
	
	bool result = false;
	bool check1, check2;
	check1 = check2 = false;
	while (!complete) {

		while (disks > 1) {
			push(to);
			push(by);
			push(from);
			push(disks);
			disks--;
			swap(to, by, temp);
		}

		move(disks, from, to);
	
		if (!isEmptyStack()) {
			disks = pop();
			from = pop();
			by = pop();
			to = pop();
			move(disks, from, to);
			disks--;
			swap(from, by, temp);
		}
		else {
			complete = 1;
		}

		if (mFinalCount > 0) { 
			result = true; 
			break; 
		}
	}

	return result;
}

void testCase::printResult()
{	
	bool result;
	result = hanoiSearach(mDiskCnt, 1, 3, 2);	
	cout << ((result) ? 1 : 0) << endl;	
}

int main()
{
	ios_base::sync_with_stdio(false);

	int caseNum;
	gFS.open("B-small.in", fstream::in);
	// gFS.open("input.in", fstream::in);
	if (!gFS.is_open()) {
		cout << "File Open Error!!!" << endl;
		exit(-1);
	}
	gFS >> caseNum;
	if (caseNum < 1) {
		cout << "Wrong Case Number" << endl;
		exit(-1);
	}

	testCase* myTest = new testCase[caseNum];
	for (int i = 0; i < caseNum; i++) {
		myTest[i].readData();
	}

	for (int i = 0; i < caseNum; i++) {
		myTest[i].printResult();
	}

	gFS.close();
	delete[] myTest;
	return 0;
}
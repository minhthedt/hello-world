#include <iostream>
#include <string.h> // memset()
#include <stdlib.h> // exit(), abs()
#include <string>
#include <algorithm> // min(), max(), sort(), is_sorted(), reverse()
#include <vector> // vector
#include <utility> // pair
#include <fstream>
#include <queue> // queue

using namespace std;

static fstream gFS;

static int gMod[10] = { 2, 3, 5, 7, 11, 13, 17, 19, 23, 29 };

struct testCase
{
	int mPageCnt;
	int mLinkCnt;
	int mStartCnt;
	int mMaxPathLength;	
	vector< vector< pair<int, int> > > mAdj; // pair(nextnode, cost(1))
	queue < pair<int, int> > mQueue; // pair(pathLength, node)
	int mPathLength[10+2]; // 2������ �����	
	void readData();
	void printResult();
	void searchPath(int start, int end);
	int dfs(int here, int count);
};

void testCase::readData()
{
	gFS >> mPageCnt >> mLinkCnt >> mStartCnt >> mMaxPathLength;
	// cout << mPageCnt << " " << mLinkCnt << " " << mStartCnt << " " << mMaxPathLength << endl;
	int node, nextNode;
	mAdj = vector< vector< pair<int, int> > >(mPageCnt + 1, vector< pair<int, int> >()); // 1���� ����	
	for (int i = 0; i < mLinkCnt; i++) {
		gFS >> node;
		gFS >> nextNode;
		mAdj[node].push_back(make_pair(nextNode, 1));
		// cout << node << ", " << nextNode << endl;
	}
	memset(mPathLength, 0x00, sizeof(mPathLength));
}

#if 0
void testCase::searchPath(int start, int end)
{
	mPathLength[start] = 0;
	while (!mQueue.empty()) { mQueue.pop(); }
	mQueue.push(make_pair(0, start)); // ó�� ���� ����

	while (!mQueue.empty()) {
		int cost = mQueue.front().first;
		int here = mQueue.front().second;
		mQueue.pop();		

		if (cost == mMaxPathLength && here != end) continue;

		if (here == end) {
			// �������� ����!
			if (cost <= mMaxPathLength) {
				mPathLength[start] += 1; // goal�� ������ ������ ���ǿ� �����ϸ� �Ѱ����� ��� ���� �߰�
				// cout << "Total Link Count of " << start << " is " << cost << ", Max Link(" << mMaxPathLength << ")" << endl;
			}			
		}

		for (int i = 0; i < (int)mAdj[here].size(); ++i) {
			int there = mAdj[here][i].first;
			int distance = cost + mAdj[here][i].second;
			if (distance <= mMaxPathLength) // ���� �湮�� max path�� �Ѿ�� �� �湮���� �ʴ´�.
			     mQueue.push(make_pair(distance, there)); // ������ �湮���� �߰��Ѵ�.
		}
	}
}
#endif

int testCase::dfs(int here, int count)
{
	int pathLength;
	int ret = 0;		

	if (count > mMaxPathLength) {
		return 0;
	}

	if (here == 1) {
		return 1;
	}	
		
	for (int i = 0; i < (int)mAdj[here].size(); ++i) {
		
		int there = mAdj[here][i].first;
		pathLength = count + 1;		
			
		ret += dfs(there, pathLength);			
	}	

	return ret;
}

void testCase::searchPath(int start, int end)
{		
	for (int i = 0; i < (int)mAdj[start].size(); ++i) {
		int next = mAdj[start][i].first;
		mPathLength[start] += dfs(next, 1);		
	}
}

void testCase::printResult()
{	
	for (int i = 0; i < mStartCnt; ++i) {
		int start = i + 2; // 2���� ����.
		searchPath(start, 1);
	}		

	for (int i = 0; i < mStartCnt; ++i) {
		cout << mPathLength[i+2] % gMod[i] << " ";
	}
	cout << endl;
}


int main()
{
	ios_base::sync_with_stdio(false);

	int caseNum;
	gFS.open("C-small.in", fstream::in);
	//gFS.open("input.in", fstream::in);
	if (!gFS.is_open()) {
		cout << "File Open Error!!!" << endl;
		exit(-1);
	}
	gFS >> caseNum;
	if (caseNum < 1) {
		cout << "Wrong Case Number" << endl;
		exit(-1);
	}

	testCase* myTest = new testCase[caseNum];
	for (int i = 0; i < caseNum; i++) {
		myTest[i].readData();
	}

	for (int i = 0; i < caseNum; i++) {
		myTest[i].printResult();
	}
	
	gFS.close();
	delete[] myTest;
	return 0;
}
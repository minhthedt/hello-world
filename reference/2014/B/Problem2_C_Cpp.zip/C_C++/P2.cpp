#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <climits>

using namespace std;

#define MAX_ARRAY 3200
unsigned int before[MAX_ARRAY];
unsigned int after[MAX_ARRAY];
//unsigned long long INT_SIZE = (1 << 32)-1;

void clear(){
	for(int i=0; i< MAX_ARRAY; i++){
		before[i]=0;
		after[i]=0;
	}
}

void print(bool isBefore){
	for(int i=MAX_ARRAY-1; i>=0; i--){
		if(isBefore){
			if (before[i]){
				cout << i << ":" << before[i] << " ";
			}
		}else
		{
			if (after[i]){
				cout << i << ":" << after[i] << " ";
			}
		}
	}
}
int isReversed(){
	for(int i=MAX_ARRAY-1; i>=0; i--){
		int bb = before[i];
		int af = after[i];
		if(before[i]>after[i]){
			return 1; //error;
		}
		else if(before[i]<after[i]){
			return 0; //ok;
		}
	}
	return 0;
}

void add(bool isBefore, int x){

	unsigned int index = x/32;
	unsigned int remained = x%32;
	unsigned int needed = 1 << remained;

	if(isBefore){


		unsigned long long bound = before[index]+needed;
		if(bound > UINT_MAX){
			before[index]= before[index] - UINT_MAX + needed;
		}
		else{
			before[index]+=needed;
		}
		while(bound > UINT_MAX){
			index++;
			bound = before[index]+1;
		}

	}else{

		unsigned long long bound = after[index]+needed;
		if(bound > UINT_MAX){
			after[index]= after[index] - UINT_MAX + needed;
		}
		else{
			after[index]+=needed;
		}
		while(bound > UINT_MAX){
			index++;
			bound = after[index]+1;
		}

	}
}

int main(int argc,  char* argv[]) {
	string filename="input.txt";

	if(argc > 1){
		filename = argv[1];
	}
	ifstream file(filename.c_str());
	string str;
	int total;
	file >> total;

	int N;
	int Num;

	for(int i=0; i < total; i++)
	{

		file >> N;
		int Max = N;

		clear();

		int src = 1;
		int dst = 2;
		int aux = 3;
		int error = 0;

		for(int j=Max; j > 0; j--){
			file >> Num;
			if(error){

			}
			else if(Num == src){
				int temp = dst;
				dst = aux;
				aux = temp;
			}else if(Num == dst){
				int temp = src;
				src = aux;
				aux = temp;

				add(true, j-1);

			}else{
				error = 1;
			}

		}

		src = 1;
		dst = 2;
		aux = 3;

		for(int j=Max; j > 0; j--){
			file >> Num;
			if(error){
			}
			else if(Num == src){
				int temp = dst;
				dst = aux;
				aux = temp;
			}else if(Num == dst){
				int temp = src;
				src = aux;
				aux = temp;
				add(false,j-1);
			}else{
				error = 1;
			}
		}

		if(!error && isReversed())
			error =1;

		//print(true);
		//print(false);
		cout << !error << endl;
	}
	return 0;
}



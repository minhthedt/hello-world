#include <stdio.h>
#include <stdlib.h>

FILE *fpin, *fpout;

int **matrix;

int divideNum[] = {2,3,5,7,11,13,17,19,23,29};

int findPath(int nodeCount, int startIndex, int end, int maxlength);

int main(){
	int caseCount;
	int nodeCount;
	int linkCount;
	int startCount;
	int maxLength;

	fpin = fopen("input.txt", "r+");
	fpout = fopen("output.txt", "w+");


	fscanf(fpin, "%d", &caseCount);

	for(int test = 0; test < caseCount; test++){
		int nodeFrom, nodeTo;
		fscanf(fpin, "%d%d%d%d", &nodeCount, &linkCount, &startCount, &maxLength);

		matrix = (int **)malloc(sizeof(int *) * nodeCount);
		for(int i = 0; i < nodeCount; i++){
			matrix[i] = (int *)malloc(sizeof(int) * nodeCount);
			for(int j = 0; j < nodeCount; j++)
				matrix[i][j] = 0;
		}

		for(int i = 0; i < linkCount; i++){
			fscanf(fpin, "%d%d", &nodeFrom, &nodeTo);
			matrix[nodeFrom-1][nodeTo-1]++;
		}

		for(int i = 1; i < startCount+1; i++){
			fprintf(fpout, "%d ", (findPath(nodeCount, i, 1, maxLength) % divideNum[i-1]));
		}
		fprintf(fpout, "\n");

		for(int i = 0; i < nodeCount; i++){
			free(matrix[i]);
		}
		free(matrix);
	}


	fclose(fpin);
	fclose(fpout);

	return 0;
}

int findPath(int nodeCount, int startIndex, int end, int maxlength){
	int allPathCount = 0;

	for(int i = 0; i < nodeCount; i++){
		if(matrix[startIndex][i] != 0){
			if(i == (end-1))
				allPathCount += matrix[startIndex][i];
			if((maxlength-1) > 0)
				allPathCount += matrix[startIndex][i] * findPath(nodeCount, i, end, maxlength-1);
		}
	}
	return allPathCount;
}

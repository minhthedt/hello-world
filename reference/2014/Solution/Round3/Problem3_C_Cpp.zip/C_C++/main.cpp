#include <iostream>
#include <fstream>
#include <list>
#include <malloc.h>
using namespace std;

class Graph
{
    int V;
    int tot_step;
    int end_node;
    unsigned long long int  **dp;
    list<int> *adj;
public:
    Graph(int V,int max_step);
    void addEdge(int v, int w);
    unsigned long long int countPaths(int s,int l);
    ~Graph();
    void disposeObject();
};

Graph::Graph(int V,int max_step)
{
    int indexj,indexi;
    this->V = V;
    this->tot_step=max_step;
    this->dp=(unsigned long long int **)calloc(V+1,sizeof(unsigned long long int *));
    for(indexj=0;indexj<=V;indexj++)
    {
        dp[indexj]=(unsigned long long int *)calloc(max_step+1,sizeof(unsigned long long int));
    }
    for(indexi=0;indexi<=V;indexi++)
        for(indexj=0;indexj<=max_step;indexj++)
            dp[indexi][indexj]=-1;
    this->end_node=1;
    adj = new list<int>[V+1];
}

Graph::~Graph()
{

}
void Graph::addEdge(int v, int w)
{
    adj[v].push_back(w);
}

unsigned long long int Graph::countPaths(int curr_node,int step)
{
    //printf("%d",tot_step);
    if(step==tot_step)
    {
        if(curr_node==end_node)
            return 1;
        return 0;
    }
    if(dp[curr_node][step]!=-1)
     return dp[curr_node][step];
    unsigned long long int result=0;
    if(curr_node==end_node)
    {
        result++;
        //dp[curr_node][step]=result;
        //return result;
    }
    list<int>::iterator i;
    for (i = adj[curr_node].begin(); i != adj[curr_node].end(); ++i)
        result+=countPaths(*i,step+1);
    dp[curr_node][step]=result;
    return result;
}

void Graph::disposeObject()
{
    delete this;
}
int main()
{
    ifstream inputFile("inputL001.txt");
    ofstream outputFile("outputL001.txt");
    int testCase=0,indexi,indexj;
    int num_page,num_link,num_start,num_max;
    int start_vertex,end_vertex;
    int start_index;
    unsigned long long int tot_path;

    int map_table[]={0,0,2,3,5,7,11,13,17,19,23,29};
    if(inputFile.is_open())
    {
        inputFile>>testCase;
        for(indexi=0;indexi<testCase;indexi++)
        {
            start_index=2;
            inputFile>>num_page;
            inputFile>>num_link;
            inputFile>>num_start;
            inputFile>>num_max;
            Graph g(num_page,num_max);
            for(indexj=0;indexj<num_link;indexj++)
            {
                inputFile>>start_vertex;
                inputFile>>end_vertex;
                g.addEdge(start_vertex, end_vertex);
            }
            for(indexj=1;indexj<=num_start;indexj++)
            {
                tot_path=g.countPaths(start_index,0);
                if(indexj<num_start)
                    outputFile<<tot_path%map_table[start_index]<<" ";
                else
                    outputFile<<tot_path%map_table[start_index]<<" "<<endl;
                start_index++;
            }
            g.disposeObject();
        }
        inputFile.close();
        outputFile.close();
    }
    return 0;
}

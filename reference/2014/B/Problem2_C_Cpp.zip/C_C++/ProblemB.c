#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int *info=0;
int *state[2];
int state_Index = 0;

int N;

printState()
{
	int i;
	for (i = 0; i < N; i++)
	{
		printf("%d ", info[i]);
	}
	printf("\n");
}

int checkState()
{
	int i;

	if (state_Index == 2)
		return 2;

	for (i = 0; i < N; i++)
	{
		if (info[i] != state[state_Index][i])
		{
			return state_Index;
		}
	}

	state_Index++;
	return state_Index;
}

void brahma(int n, int from, int temp, int to)
{
	if (n == 1)
	{
//		printf("%d : %d => %d\n", n, from, to);
		info[n-1] = to;
//		printState(); 
		if(checkState()>1)
			return;
	}
	else
	{
		brahma(n - 1, from, to, temp);
//		printf("%d : %d => %d\n", n, from, to);
		info[n-1] = to;
//		printState();
		if (checkState()>1)
			return;
		brahma(n - 1, temp, from, to);
	}
}

void main()
{
	FILE *in, *out;
	int T;
	int i = 0, j = 0;

	//file I/O
	if ((in = fopen("B-small.in", "r")) == 0)
	{
		printf("Input File error!!\n");
		return;
	}

	if ((out = fopen("output.txt", "w")) == 0)
	{
		printf("Output File error!!\n");
		return;
	}

	//Read Number of TestCase
	fscanf(in, "%d", &T);

	for (i = 0; i < T; i++)
	{
		fscanf(in, "%d", &N);
		info = (int*)malloc(sizeof(int)*N);
		state[0] = (int*)malloc(sizeof(int)*N);
		state[1] = (int*)malloc(sizeof(int)*N);

		state_Index = 0;

		//init info 
		for (j = 0; j < N; j++)
		{
			info[j] = 1;
		}

		//init state
		for (j = N-1; j > -1; j--)
		{
			fscanf(in, "%d", &state[0][j]);
		}
		for (j = N-1; j > -1; j--)
		{
			fscanf(in, "%d", &state[1][j]);
		}

		if (checkState() == 1)
		{
			fprintf(out, "0\n");
			continue;
		}

		//printf("test T #%d\n", i);
		//printState();
		checkState();
		brahma(N, 1, 3, 2);

		if (state_Index == 2)
			fprintf(out, "1\n");
		else
			fprintf(out, "0\n");

		free(info);
		free(state[0]);
		free(state[1]);
	}

	

	//free FD
	if (in != 0)
	{
		fclose(in);
	}

	if (in != 0)
	{
		fclose(out);
	}

	printf("End!!!\n");
	return;
}


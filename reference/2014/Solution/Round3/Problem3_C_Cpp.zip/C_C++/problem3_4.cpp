#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int L,N;
int **link;
int *linkSize;
unsigned __int64 **info;

void getInfo(int K);
int getNumberOfPath_org(int start, int length);

void printDebug()
{
	int page, length;
	for (page = 0; page < N; page++)
	{
		for (length = 0; length < L + 1; length++)
		{
			printf("%u ", info[page][length]);
		}
		printf("\n");
	}
	getchar();
}

void main()
{
	FILE *in, *out;
	int T;
	int i = 0, j = 0, k = 0;
	unsigned __int64 Numbers[10] = { 2, 3, 5, 7, 11, 13, 17, 19, 23, 29 };
	
	//file I/O
	if ((in = fopen("C-large.in", "r")) == 0)
	//if ((in = fopen("input.txt", "r")) == 0)
	//if ((in = fopen("C-small.in", "r")) == 0)
	{
		printf("Input File error!!\n");
		return;
	}

	if ((out = fopen("output.txt", "w")) == 0)
	{
		printf("Output File error!!\n");
		return;
	}

	//Read Number of TestCase
	fscanf(in, "%d", &T);

	for (i = 0; i < T; i++)
	{
		//��������  ��  N,  ��ũ��  ��  M,  �������  ��  K,  �����  �ִ�  ����  L
		int M, K;
		int temp=0;

		fscanf(in, "%d %d %d %d", &N, &M, &K, &L);
		link = (int **)malloc(sizeof(int*)*N);
		linkSize = (int *)malloc(sizeof(int)*N);
		info = (unsigned __int64 **)malloc(sizeof(unsigned __int64)*N);

		memset(linkSize, 0x00, sizeof(int)*N);
		printf("%d %d %d %d\n", N, M, K, L);

		for (j = 0; j < N; j++)
		{
			link[j] = (int *)malloc(sizeof(int)*M);
			memset(link[j], 0x00, sizeof(int)*M);

			info[j] = (unsigned __int64 *)malloc(sizeof(unsigned __int64)*(L + 1));
		}

		//init link
		for (j = 0; j < M; j++)
		{
			int page1, page2;
			fscanf(in, "%d %d", &page1, &page2);
			link[page1 - 1][linkSize[page1 - 1]++] = page2;
		}

		

		//get number of link
		for (j = 1; j < K + 1; j++)
		{
			unsigned __int64  result = 0;

			getInfo(j);
			for (k = 0; k < L + 1; k++)
			{
				result += info[j][k];
			}

			//printf("%u ", result);
			fprintf(out,"%d ", result%Numbers[j-1]);
		}

		//printf("\n");
		fprintf(out,"\n");
		
		//free memory
		if (linkSize)
		{
			free(linkSize);
		}
		
		if (link)
		{
			for (j = 0; j < N; j++)
			{
				free(link[j]);
			}
			free(link);
		}

		if (info)
		{
			for (j = 0; j < N; j++)
			{
				free(info[j]);
			}
			free(info);
		}
	}

	//free FD
	if (in != 0)
	{
		fclose(in);
	}

	if (in != 0)
	{
		fclose(out);
	}

	printf("End!!!\n");
	return;
}

//��������  ��  N,  ��ũ��  ��  M,  �������  ��  K,  �����  �ִ�  ����  L
void getInfo(int K)
{
	int length, page, k;
	unsigned __int64 Numbers[10] = { 2, 3, 5, 7, 11, 13, 17, 19, 23, 29 };

	for (length = 0; length < L + 1; length++)
	{
		for (page = 0; page < N; page++)
		{
			if (length == 0)
			{
				if (page == 0)
				{
					info[page][length] = 1;
				}
				else
				{
					info[page][length] = 0;
				}
			}
			else
			{
				unsigned __int64  re = 0;
				for (k = 0; k < linkSize[page]; k++)
				{
					re += (info[link[page][k] - 1][length - 1]%Numbers[K-1]);
				}

				info[page][length] = re%Numbers[K-1];
			}
		}
	}

	return;
}

#include <stdio.h>
#include <conio.h>
#include <stdlib.h>


/*
void mul(){
	int b[10][10],i,j,k;
	for(i=0;i < r;i++){
		for(j=0;j < r;j++){
			b[i][j]=0;
			for(k=0;k < r;k++)
				b[i][j]=b[i][j]+a[i][k]*c[k][j];
		}
	}
	for(i=0;i < r;i++){
		for(j=0;j < r;j++)
			c[i][j]=b[i][j];
	}
}
*/

int countwalks(int **graph, int u, int v, int k,int V){
   // Base cases
	int count,i;
   if (k == 0 && u == v)      
	   return 1;
   if (k == 1 && graph[u][v]) 
	   return graph[u][v];
   if (k <= 0)                
	   return 0;
 
   // Initialize result
   count = 0;
 
   // Go to all adjacents of u and recur
   for (i = 0; i < V; i++)
       if (graph[u][i])  // Check if is adjacent of u
           count += graph[u][i]*countwalks(graph, i, v, k-1,V);
 
   return count;
}


void main(){
	FILE *fp ,*fp2;
	int nTest, nPage,nLink,nSP,mLink,i,j,l,s,t,**link,*path,k=0,count=0,prime[10]={2,3,5,7,11,13,17,19,23,29};
	fp = fopen("input3.txt","r");
	fp2 = fopen("output3.txt","w");
	if(!fp){
		printf("file error\n");
		exit(1);
	}
	if(!fp2){
		printf("file error\n");
		exit(1);
	}
	fscanf(fp,"%d",&nTest);
	for(l=0;l<nTest;l++){
		fscanf(fp,"%d%d%d%d",&nPage,&nLink,&nSP,&mLink);
		link =(int **)calloc(nPage,sizeof(int *));
		for(i=0;i<nPage;i++)
			*(link+i)=(int *)calloc(nPage,sizeof(int));
		path =(int *)calloc(nSP,sizeof(int));
		for(i=0;i<nLink;i++){
			fscanf(fp,"%d%d",&s,&t);
			link[s-1][t-1]+=1;
		}
		for(i=1;i<=nSP;i++){
			for(k=1;k<=mLink;k++){
				path[i-1]+=countwalks(link,i,0,k,nPage);
			}
		}
		for(i=0;i<nSP;i++)
			fprintf(fp2,"%d ",path[i]%prime[i]); 
		fprintf(fp2,"\n");
		for(i=0;i<nPage;i++)
			free(link[i]);
		free(link);
		free(path);
	}
	fclose(fp);
	fclose(fp2);
	getch();
}

			
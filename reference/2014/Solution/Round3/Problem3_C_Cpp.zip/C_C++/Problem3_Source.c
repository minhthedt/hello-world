#include <stdio.h>

#define FILE_NAME_SIZE 256
#define MAX_N 1000
#define MAX_K 10
#define MAX_L 10000

int T, N, M, K, L;
int linksSiz;
int web[MAX_N][MAX_N], links[MAX_L], cases[MAX_K];
int divisor[MAX_K] = {2, 3, 5, 7, 11, 13, 17, 19, 23, 29};

void get_file_name(char *input, char *output)
{
	printf("Input File Name : ");
	gets(input);
	printf("Output File Name: ");
	gets(output);
}

void csw(int page)
{
	int subcases = 1;
	int i;

	if(linksSiz == L){
		if(page>=2 && page<=K+1){
			for(i=0; i<linksSiz; i++){
				subcases *= (links[i]%divisor[page-2]);
				subcases %= divisor[page-2];
			}
			cases[page-2] = (cases[page-2]+subcases) % divisor[page-2];
		}
		linksSiz--;
		return;
	}

	for(i=0; i<N; i++){
		if(web[page-1][i]){
			links[linksSiz++] = web[page-1][i];
			csw(i+1);
		}
	}

	if(linksSiz >0){
		if(page>=2 && page<=K+1){
			for(i=0; i<linksSiz; i++){
				subcases *= (links[i]%divisor[page-2]);
				subcases %= divisor[page-2];
			}
			cases[page-2] = (cases[page-2]+subcases) %divisor[page-2];
		}
		linksSiz--;
	}
}

void main()
{
	FILE *ifp, *ofp;
	int page1, page2;
	int i, j, k;
	char input[FILE_NAME_SIZE], output[FILE_NAME_SIZE];

	printf("Problem3\n");
	get_file_name(input, output);

	ifp = fopen(input, "r");
	ofp = fopen(output, "w");

	if(ifp == NULL || ofp == NULL){
		printf("File Open Error!!!\n");
		return ;
	}

	fscanf(ifp, "%d", &T);

	for(i=0; i<T; i++){
		fscanf(ifp, "%d%d%d%d", &N, &M, &K, &L);

		for(j=0; j<N; j++){
			for(k=0; k<N; k++)
				web[j][k] = 0;
		}
		for(j=0; j<K; j++)
			cases[j] = 0;

		for(j=0; j<M; j++){
			fscanf(ifp, "%d%d", &page1, &page2);
			web[page2-1][page1-1]++;
		}

		linksSiz = 0;
		csw(1);

		for(j=0; j<K; j++)
			fprintf(ofp, "%d ", cases[j]);
		fprintf(ofp, "\n");
	}

	fclose(ifp);
	fclose(ofp);

}

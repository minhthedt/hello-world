#include <stdio.h>
#include <stdlib.h>

#define FILE_NAME_SIZE 256
#define swap(x, y) ((x)^=(y)^=(x)^=(y))

void get_file_name(char *input, char *output)
{
	printf("Input File Name : ");
	gets(input);
	printf("Output File Name: ");
	gets(output);
}

void main()
{
	FILE *ifp, *ofp;
	int T, N;
	int pos, from, to, tmp;
	int *disc2, *disc3;	// disc(DAY)[i] : N-i���� ������ �ű� ��, ���� ū ������ from�� ������ 0, to�� ������ 1
	int stage;	// 2°��, 3°���� ���Ͽ� ���� �ܰ�� ����Ǿ��°� true�� 1, false�� 0
	int i, j, k;
	char input[FILE_NAME_SIZE], output[FILE_NAME_SIZE];
	
	printf("Problem2\n");
	get_file_name(input, output);

	ifp = fopen(input, "r");
	ofp = fopen(output, "w");

	if(ifp == NULL || ofp == NULL){
		printf("File Open Error!!!\n");
		return ;
	}

	fscanf(ifp, "%d", &T);
	
	for(i=0; i<T; i++){
		fscanf(ifp, "%d", &N);
		
		disc2 = (int*)malloc(sizeof(int)*N);
		disc3 = (int*)malloc(sizeof(int)*N);
		from = 1;  to = 2;  tmp = 3;
		
		for(j=0; j<N; j++){
			fscanf(ifp, "%d", &pos);
			
			if(pos == from){
				disc2[j] = 0;
				swap(to, tmp);
			}
			else if(pos == to){
				disc2[j] = 1;
				swap(from, tmp);
			}
			else
				break;
		}

		if(j < N){
			fprintf(ofp, "0\n");
			for(k=j+1; k<2*N; k++)
				fscanf(ifp, "%d", &pos);
		}
		else{
			from = 1;  to = 2;  tmp = 3;
			
			for(j=0; j<N; j++){
				fscanf(ifp, "%d", &pos);

				if(pos == from){
					disc3[j] = 0;
					swap(to, tmp);
				}
				else if(pos == to){
					disc3[j] = 1;
					swap(from, tmp);
				}
				else
					break;
			}

			if(j < N){
				fprintf(ofp, "0\n");
				for(k=j+1; k<N; k++)
					fscanf(ifp, "%d", &pos);
			}
			else{
				stage = 1;
				for(k=0; k<N; k++){
					if(disc2[k] < disc3[k]){
						stage = 1;
						break;
					}
					else if(disc2[k] > disc3[k]){
						stage = 0;
						break;
					}
				}
				fprintf(ofp, "%d\n", stage);
			}			
		}
	
		free(disc2);
		free(disc3);
	}

	fclose(ifp);
	fclose(ofp);
}

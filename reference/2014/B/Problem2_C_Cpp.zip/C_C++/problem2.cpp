#include <iostream>

using namespace std;

int disknum;

bool checkProgress(int disk[], int progress[]) {
	int cur = 1;
	int target = 2;
	int donot = 3;
	int tmp;

	for (int i = 0; i < disknum; i++) {
		if (disk[i] == donot) {
			return false;
			break;
		}
		if (disk[i] == target) {
			cur = donot;
			donot = 6 - cur - target;
			progress[i] = 1;
		} else {
			tmp = target;
			target = donot;
			donot = tmp;
		}
	}
	
	return true;
}

bool compareProgress(int second[], int third[]) {
	for (int i = 0; i < disknum; i++) {
		if (second[i]) {
			if (third[i] == 0) {
				break;
			}
		} else {
			if (third[i]) {
				return true;
			}
		}
	}
	if (i < disknum) {
		return false;
	}
	return true;
}

int main() {

	FILE *infile, *outfile;
	int cases;

	infile = fopen("B-large.in", "r");
	outfile = fopen("result.out", "w");
	
	fscanf(infile, "%d", &cases);

	while (cases > 0) {
		
		int* second;
		int* third;
		int i, result = -1;

		fscanf(infile, "%d", &disknum);
		second = new int[disknum];
		third = new int[disknum];

		//cout << "disk = " << disknum << endl;

		for (i = 0; i < disknum; i++) {
			fscanf(infile, "%d", &second[i]);
		}
		for (i = 0; i < disknum; i++) {
			fscanf(infile, "%d", &third[i]);
		}
		for (i = 0; i < disknum; i++) {
			if (second[i] != third[i]) {
				break;
			}
		}
		if (i == disknum) {
			result = 0;
		}
		for (i = 0; i < disknum; i++) {
			if (second[i] != 1) {
				break;
			}
		}
		if (i == disknum) {
			result = 0;
		}
		if (result == 0) {
			fprintf(outfile, "%d\n", result);
			cases--;
			continue;
		}

		///////////////////////////////////////////////////
		
		int* progress1;
		int* progress2;
		progress1 = new int[disknum];
		progress2 = new int[disknum];
		memset(progress1, 0, sizeof(int) * disknum);
		memset(progress2, 0, sizeof(int) * disknum);

		result = 0;

		if (checkProgress(second, progress1)) {
			if (checkProgress(third, progress2)) {
				if (compareProgress(progress1, progress2)) {
					result = 1;
				}
			}
		}

		fprintf(outfile, "%d\n", result);

		delete second;
		delete third;
		delete progress1;
		delete progress2;

		///////////////////////////////////////////////////

		cases--;
	}
	
	if (infile != NULL) {
		fclose(infile);
		fclose(outfile);
	}

	return 0;
}
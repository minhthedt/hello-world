// 2014_3_Prob3.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include <stdio.h>
#include <stdlib.h>
#include <memory.h>

typedef struct _LINKS {
	int num;
	int *dest;
	int *weight;
} LINKS;

int _tmain(int argc, _TCHAR* argv[])
{
	FILE *fpin, *fpout;

	int divider[] = {2,3,5,7,11,13,17,19,23,29};

	LINKS *links = (LINKS *)calloc(1024, sizeof(LINKS));

	int *weight[2];
	int *w[2], *tmp;

	int T, N, M, K, L;
	int num1, num2;
	int sum;

	fpin = fopen(argv[1], "r");
	fpout = fopen("out.txt", "w");

	weight[0] = (int *)calloc(1024, sizeof(int));
	weight[1] = (int *)calloc(1024, sizeof(int));
	
	fscanf(fpin, "%d", &T);

	for(int t=0;t<T;t++)
	{
		fscanf(fpin, "%d %d %d %d", &N, &M, &K, &L);

		for(int m=0;m<M;m++)
		{
			fscanf(fpin, "%d %d", &num1, &num2);

			// �����ΰ�� �޸� �Ҵ�
			if(links[num1].num == 0) {
				links[num1].dest = (int *)malloc(sizeof(int) * 10);
				links[num1].weight = (int *)malloc(sizeof(int) * 10);
				links[num1].dest[0] = num2;
				links[num1].weight[0] = 1;
				links[num1].num++;
			} else {
				int i;
				// ã�Ƽ� �� ����
				for(i=0;i<links[num1].num;i++)
				{
					if(links[num1].dest[i] == num2) {
						links[num1].weight[i]++;
						break;
					}
				}
				// ��ã�� ��� �߰�
				if(i==links[num1].num)
				{
					// 10�� ���� �ѱ�� ��� �޸� ���Ҵ� (��ũ 10000���� ������ 1000�� �̹Ƿ� ��� 10�� ����)
					if(links[num1].num % 10 == 0) {
						links[num1].dest = (int *)realloc(links[num1].dest, sizeof(int) * (links[num1].num + 10));
						links[num1].weight = (int *)realloc(links[num1].weight, sizeof(int) * (links[num1].num + 10));
					}
					links[num1].dest[links[num1].num] = num2;
					links[num1].weight[links[num1].num] = 1;
					links[num1].num++;
				}
			}
		}

		// k �� �ݺ� (��� ������� ���� Ȯ��)
		for(int k=0;k<K;k++)	// �ִ� 10
		{
			w[0] = weight[0];
			w[1] = weight[1];
			sum = 0;

			memset(w[0], 0, sizeof(int) * 1024);

			// �ʱⰪ ���� (ù ��ũ)
			for(int iter=0;iter<links[k+2].num;iter++)
			{
				w[0][links[k+2].dest[iter]] = links[k+2].weight[iter] % divider[k];
			}

			sum = w[0][1];

			// L-1���� ��ũ �ݺ�
			for(int val=1;val<L;val++)	// �ִ� 10000
			{
				memset(w[1], 0, sizeof(int) * 1024);
				
				// �����ϴ� ��� ��忡 ���ؼ�
				for(int n=1;n<=N;n++) // �ִ� 1000
				{
					if(w[0][n] == 0) continue;
					
					for(int iter=0;iter<links[n].num;iter++)
					{
						w[1][links[n].dest[iter]] = (w[1][links[n].dest[iter]] + w[0][n] * (links[n].weight[iter] % divider[k])) % divider[k];
					}
				}

				tmp = w[0];
				w[0] = w[1];
				w[1] = tmp;

				sum = (sum + w[0][1]) % divider[k];
			}

			fprintf(fpout, "%d ", sum);
		}
		fprintf(fpout, "\n");

		for(int i=0;i<1024;i++)
		{
			if(links[i].num == 0) continue;

			free(links[i].dest);
			free(links[i].weight);
			links[i].num = 0;
		}
	}

	free(weight[0]);
	free(weight[1]);
	free(links);

	fclose(fpin);
	fclose(fpout);

	return 0;
}


/*
 * author: Alex Matyzhonok (alex.matyzhonok@lge.com)
 * LGECodejam
 * Problem 3
 */


#include <vector>
#include <iostream>
#include <fstream>

int modTable[] = {2, 3, 5, 7, 11, 13, 17, 19, 23, 29};

struct Node
{

    Node()
    : m_ways(0)
    , m_mod(-1) { }

    Node(int number)
    : m_ways(0)
    , m_mod(number <= 12 ? modTable[number - 2] : -1) 
    {
    }

    void AddChild(int index)
    {
        m_links.push_back(index);
    }

    void Inc()
    {
        ++m_ways;
        if (m_ways == m_mod)
            m_ways = 0;
    }

    const std::vector<int>& Children() const
    {
        return m_links;
    }

    int Ways() const
    {
        return m_ways;
    }
private:
    std::vector<int> m_links;
    int m_ways;
    char m_mod;
};

void FindAllPathes(std::vector<Node>& nodes, int currentNode, int Depth)
{
    nodes[currentNode].Inc();

    if (Depth == 0)
        return;

    const std::vector<int>& children = nodes[currentNode].Children();
    for (int i = 0, e = children.size(); i != e; ++i)
        FindAllPathes(nodes, children[i], Depth - 1);
}

int main(int argc, char** argv)
{
    std::ifstream input("input.txt");
    if (!input.is_open()){
        std::cout << "can not open input" << std::endl;
        return 1;
    }

    std::ofstream out("rez.out");
    if (!out.is_open()){
        std::cout << "can not open output" << std::endl;
        return 1;
    }

    unsigned long T;
    input >> T;

    for (unsigned long long j = 0; j < T; ++j) {
        int N, M, K, L;
        input >> N;
        input >> M;
        input >> K;
        input >> L;

        std::vector<Node> nodesvector(N + 1);

        for (int i = 2; i <= K+1; ++i)
            nodesvector[i] = Node(i);

        for (int i = 0; i < M; ++i) {
            int start, end;
            input >> start;
            input >> end;
            nodesvector[end].AddChild(start);
        }

        FindAllPathes(nodesvector, 1, L);

        for (int i = 2; i <= K + 1; ++i)
            out << int(nodesvector[i].Ways()) << " ";
        out << std::endl;

    }

    return 0;
}


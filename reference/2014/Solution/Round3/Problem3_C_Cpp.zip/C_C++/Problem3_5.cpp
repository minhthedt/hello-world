/*
 ============================================================================
 Name        : Problem3.c
 Copyright   : Copyright(c) 2014 by LG Electronics Inc.
 ============================================================================
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

//#define DEBUG

typedef unsigned int uint32;

static const int MOD[10] = { 2, 3, 5, 7, 11, 13, 17, 19, 23, 29 };
static int T=0, N=0, M=0, K=0, L=0;

uint32 *map1;
uint32 *mapLA, *mapLB;

#define SWAP(A, B, T) ((T)=(A), (A)=(B), (B)=(T))
#define ARRAY(A, x, y) A[x * N + y]

static int count_path1(uint32 *mapB, uint32 *mapA, uint32 mod) {

    int exist = 0;
    for (int x=1; x <= N; x++) {
        unsigned int count = 0;
        for (int y=1; y <= N; y++) {
            if (x == y) continue;
#ifdef DEBUG
            count = (count + ARRAY(mapA, x, y) * ARRAY(mapA, 0, y));
#else
            count = (count + ARRAY(mapA, x, y) * ARRAY(mapA, 0, y)) % mod;
#endif
        }
        ARRAY(mapB, 0, x) = count;
        if (count > 0)
            exist = 1;
    }
    return exist;
}

static void print_map(uint32 *map) {
    for (int x = 1; x <= N ; x++) {
        fprintf(stderr,"%2u : ", ARRAY(map, 0, x)); 
        for (int y = 1; y <= N ; y++) {
            fprintf(stderr,"%u ", ARRAY(map, x, y)); 
        }
        fprintf(stderr,"\n"); 
    }
    fprintf(stderr,"-----\n"); 
}

int main(void) {

	if (fscanf(stdin, "%d", &T) <= 0) {
		fputs("invalid input!\n", stderr);
		exit(EXIT_FAILURE);
	}
#ifdef DEBUG
    fprintf(stderr, "T=%d\n", T);
#endif

    while (T-- > 0) {

        if (fscanf(stdin, "%d %d %d %d", &N, &M, &K, &L) <= 0 
                || !(N >= 2 && N <= 1000)
                || !(M >= 1 && M <= 10000)
                || !(K >= 1 && K <= 10)
                || !(L >= 1 && L <= 10000)
           ) {
            fputs("invalid input!\n", stderr);
            exit(EXIT_FAILURE);
        }
#ifdef DEBUG
        fprintf(stderr, "N=%d, M=%d, K=%d, L=%d\n", N, M, K, L);
#endif

        map1 = (uint32*)malloc(sizeof(uint32)*(N+1)*(N+1));
        memset(map1, 0x00, sizeof(uint32)*(N+1)*(N+1));

        for (int i = 0; i < M; i++) {
            unsigned int x=0, y=0;
            if (fscanf(stdin, "%d %d", &x, &y) <= 0 || x > N || y > N || x == y) {
                fputs("invalid data\n", stderr);
                exit(EXIT_FAILURE);
            }
            ARRAY(map1, x, y)++;
        }

        uint32 *pathL = (uint32*)malloc(sizeof(uint32)*(K+2));
        // L == 1
        for (int x = 2; x <= K+1 ; x++) {
#ifdef DEBUG
            pathL[x] = ARRAY(map1, x, 1);
#else
            pathL[x] = ARRAY(map1, x, 1) % MOD[x-2];
#endif
        }

        // L > 1
        mapLA = (uint32*)malloc(sizeof(uint32)*(N+1)*(N+1));
        mapLB = (uint32*)malloc(sizeof(uint32)*(N+1)*(N+1));
        memcpy(mapLA, map1, sizeof(uint32)*(N+1)*(N+1));
        memcpy(mapLB, map1, sizeof(uint32)*(N+1)*(N+1));

        for (int x = 2; x <= K+1 ; x++) {
            int mod = MOD[x-2];
            uint32 *temp;
            for (int s = 1 ; s <= N ; s++) {
               ARRAY(mapLA, 0, s) = ARRAY(map1, s, 1); // result of L = 1;
            }
#ifdef DEBUG
            print_map(mapLA);
#endif
            for (int i = 2; i <= L ; i++) {
                if (count_path1(mapLB, mapLA, mod) == 0)
                    break;
#ifdef DEBUG
                print_map(mapLB);
                pathL[x] = (pathL[x] + ARRAY(mapLB, 0, x));
#else
                pathL[x] = (pathL[x] + ARRAY(mapLB, 0, x)) % mod;
#endif
                SWAP(mapLA, mapLB, temp);
            }
            fprintf(stdout,"%u ", pathL[x]);
        }

        fprintf(stdout,"\n"); 

        free(map1);
        free(mapLA);
        free(mapLB);
        free(pathL);
    }
    return EXIT_SUCCESS;
}


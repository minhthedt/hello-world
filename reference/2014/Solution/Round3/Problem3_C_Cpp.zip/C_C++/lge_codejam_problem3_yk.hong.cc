#include <algorithm>
#include <cassert>
#include <fstream>
#include <iostream>
#include <list>
#include <vector>

// Input info for each test case.
struct InputInfo {
  int page_num;
  int link_num;
  int start_link_count;
  int target_link_num; 

  void Print() {
    //std::cout << "page_num: " << page_num << std::endl;
    //std::cout << "link_num: " << link_num << std::endl;
    std::cout << "start_link_count: " << start_link_count << std::endl;
    std::cout << "target_link_num: " << target_link_num << std::endl;
  }
};

struct Node {
  std::vector<int> adjacent_node;
  std::vector<int> adjacent_node_count;
};

void PrintResult(std::vector<int>& result);
void PrintGraph(std::vector<Node*>& graph);
void PrintGraph2(int graph2[][1001]);
InputInfo ConstructGraph(std::ifstream& input_file, std::vector<Node*>& graph, int graph2[][1001]);
int CalcPath(std::vector<int>& pass, int graph2[][1001]);
void CalcChildVisitWays(std::vector<Node*>& graph,
                       int graph2[][1001],
                       std::vector<int> pass,
                       std::vector<int>& result,
                       int start_node,
                       int node,
                       int current_link_count,
                       int target_link_num);

int main(int argc, char** argv) {
  std::ifstream input_file;
  input_file.open(argv[1]);

  // number of test cases.
  int test_cases;
  input_file >> test_cases;

  for (int i = 0; i < test_cases; ++i) {
    //std::cout << "Test " << i << " : ";
    std::vector<Node*> graph(1000, NULL);
    int graph2[1001][1001] = {0, };

    InputInfo input_info = ConstructGraph(input_file, graph, graph2);

    // Print graph
    //input_info.Print();
    //PrintGraph(graph);
    //PrintGraph2(graph2);

    // Solve
    std::vector<int> result(input_info.start_link_count, 0);
    for (int j = 0; j < input_info.start_link_count; ++j) {
      std::vector<int> pass;
      CalcChildVisitWays(graph, graph2, pass, result, j + 2, j + 2, 0, input_info.target_link_num);
    }
    PrintResult(result);
  }
}

void PrintResult(std::vector<int>& result) {
  int divider[] = {2, 3, 5, 7, 11, 13, 17, 19, 23, 29};
  for (int i = 0; i < result.size(); ++i) {
    if (i != 0)
      std::cout << " ";
    std::cout << result[i] % divider[i]; 
    //std::cout << result[i]; 
  }

  std::cout << std::endl;
}
void CalcChildVisitWays(std::vector<Node*>& graph,
                       int graph2[][1001],
                       std::vector<int> pass,
                       std::vector<int>& result,
                       int start_node,
                       int node,
                       int current_link_count,
                       int target_link_num) {
  pass.push_back(node);
  if (node == 1) {
    result[start_node - 2] += CalcPath(pass, graph2);

 //   if (current_link_count + 1 == target_link_num)
      return;
  }

  if (current_link_count == target_link_num)
    return;

  Node* n = graph[node];
  if (n == NULL)
    return;
  for (int i = 0; i < n->adjacent_node.size(); ++i) {
    CalcChildVisitWays(graph, graph2, pass, result, start_node, n->adjacent_node[i], current_link_count + 1, target_link_num);
  }
}

int CalcPath(std::vector<int>& pass, int graph2[][1001]) {
  int result = 1;

  for (int i = 0; i < pass.size() - 1; ++i) {
    result = result * graph2[pass[i]][pass[i+1]];
  }

  return result;
}

InputInfo ConstructGraph(std::ifstream& input_file, std::vector<Node*>& graph, int graph2[][1001]) {
  InputInfo info;
  input_file >> info.page_num;
  input_file >> info.link_num;
  input_file >> info.start_link_count;
  input_file >> info.target_link_num;

  int start_page;
  int target_page;
  for (int j = 0; j < info.link_num; ++j) {
    input_file >> start_page;
    input_file >> target_page;
    Node* node = graph[start_page];
    graph2[start_page][target_page]++;
    if (node == NULL) {
      Node* new_node = new Node;
      new_node->adjacent_node.push_back(target_page);
      new_node->adjacent_node_count.push_back(1);
      graph[start_page] = new_node;
    } else {
      std::vector<int>::iterator iter = std::find(node->adjacent_node.begin(),
                                                  node->adjacent_node.end(),
                                                  target_page);
      if (iter == node->adjacent_node.end()) {
        node->adjacent_node.push_back(target_page);
        node->adjacent_node_count.push_back(1);
      } else {
        int vector_index = iter - node->adjacent_node.begin();
        node->adjacent_node_count[vector_index]++;
      }
    }
  }

  return info;
}

void PrintGraph2(int graph2[][1001]) {
  for (int i = 1; i < 1001; ++i) {
    for (int j = 1; j < 1001; ++j) {
      if (graph2[i][j] == 0)
        continue;
      std::cout << i << "->" << j << ": " << graph2[i][j] << std::endl;
    }
  }
}
void PrintGraph(std::vector<Node*>& graph) {
  for (int i = 1; i < graph.size(); ++i) {
    if (graph[i] == NULL)
      continue;
      //return;
    assert(graph[i]->adjacent_node.size() == graph[i]->adjacent_node_count.size());
    for (int j = 0; j < graph[i]->adjacent_node.size(); ++j) {
      std::cout << i << "->" << graph[i]->adjacent_node[j] << ": "
                << graph[i]->adjacent_node_count[j] << std::endl;
    }
  }
}


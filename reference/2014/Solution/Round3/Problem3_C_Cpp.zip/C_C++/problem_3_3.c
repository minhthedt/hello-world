#include <stdio.h>
#include <stdlib.h>
#include <conio.h>
#include <string.h> 
#include <time.h>

#pragma warning(disable: 4996)


typedef struct _LINEINFO{
	int count;
	int length;
	int end;
	int start;
	int count_per_lenth[10010];
	int sum_count;
	void *next;
} LINEINFO;


typedef struct _MPOINT{
	LINEINFO *start_ptr;
	int updated;
} MPOINT;

void read_a_case(FILE *TC, FILE *file_out);
int conect_info[1010][1010];
MPOINT mPoint[1010];

void main()
{
	FILE *fp_tc, *fp_result;
	int nCase, i;
	fp_tc = fopen("d:\\C-small.in", "r");
	fp_result = fopen("d:\\result.txt", "w");
	fscanf(fp_tc, "%d\n", &nCase);
	for (i = 0; i < nCase; i++)
	{
		read_a_case(fp_tc, fp_result);
	}

	fclose(fp_tc);
	fclose(fp_result);
}

void read_a_case(FILE *TC, FILE *file_out)
{
	int allow_length = 0,vertex_count=0,line_count=0,start_point_count,i,j;
	int line_start, line_end, update=0;
	memset(conect_info, 0x00, sizeof(int)* 1010 * 1010);
	memset(mPoint, 0x00, sizeof(MPOINT)* 1010);

	fscanf(TC, "%d %d %d %d\n", &vertex_count, &line_count, &start_point_count, &allow_length);

	mPoint[1].updated = 1;
	mPoint[1].start_ptr = malloc(sizeof(LINEINFO));
	memset(mPoint[1].start_ptr, 0x00, sizeof(LINEINFO));
	(mPoint[1].start_ptr)->next = NULL;


	for (i=0;i<line_count;i++)
	{
		fscanf(TC, "%d %d\n",&line_start,&line_end);
		conect_info[line_end][line_start]++;
	}

	int graph_update = 1;
	while (graph_update !=0)
	{
			graph_update = 0;
			for (i = 1; i < vertex_count+1; i++)
			{
					for (j = 1; j < vertex_count+1; j++)
					{
						if (conect_info[j][i] != 0x00)
						{
							if (mPoint[j].updated == 1) 
							{                           
								LINEINFO *curren_start_ptr;
								LINEINFO *dest_start_ptr;
								curren_start_ptr = mPoint[i].start_ptr; 
								dest_start_ptr = mPoint[j].start_ptr;
								int temp_count_per_lenth[10010];
								memset(temp_count_per_lenth, 0x00, sizeof(int)*10010);

								while (dest_start_ptr != NULL)
								{
									for (int k = 0; k < allow_length+1; k++)
									{
										temp_count_per_lenth[k+1] = temp_count_per_lenth[k+1]+ dest_start_ptr->count_per_lenth[k];
									}
									dest_start_ptr = dest_start_ptr->next;
								}
								if (j == 1)
									temp_count_per_lenth[1] = 1;

								if (curren_start_ptr == NULL)
								{
									LINEINFO *start_ptr;
									mPoint[i].start_ptr = malloc(sizeof(LINEINFO));
									curren_start_ptr = mPoint[i].start_ptr;
									memset(curren_start_ptr, 0x00, sizeof(LINEINFO));
									curren_start_ptr->next = NULL;
									curren_start_ptr->start = i;
									curren_start_ptr->end = j;
								}
								int obj_find = 0;
								while (curren_start_ptr != NULL)
								{
									if (curren_start_ptr->end == j)
									{
										obj_find = 1;
										break;
									}
									if (curren_start_ptr->next == NULL)
										break;
									curren_start_ptr = curren_start_ptr->next;
								}

								if (obj_find == 0x00)
								{
									LINEINFO *obj_ptr;
									obj_ptr = malloc(sizeof(LINEINFO));
									obj_ptr->next = NULL;
									obj_ptr->start = i;
									obj_ptr->end = j;
									curren_start_ptr->next = obj_ptr;

								}
								//�� ���� �����߿� ������� �´°��� ã�´�. 
									int find = 0;
									curren_start_ptr = mPoint[i].start_ptr;
									while (curren_start_ptr != NULL && find==0)
									{
										if (curren_start_ptr->end == j)
										{
											int pp;
											find = 1;
											int tempsum = 0;
											for (pp = 0; pp < allow_length+1; pp++)
											{
												temp_count_per_lenth[pp] = temp_count_per_lenth[pp] * conect_info[j][i];
												tempsum = tempsum + temp_count_per_lenth[pp];
											}


											for (pp = 0; pp < allow_length+1; pp++)
											{
												if (curren_start_ptr->count_per_lenth[pp] != temp_count_per_lenth[pp])
												{
													graph_update = 1;
													mPoint[i].updated = 1;
													memcpy(curren_start_ptr->count_per_lenth, temp_count_per_lenth, sizeof(int)* 10000);
													curren_start_ptr->sum_count = tempsum;
													pp = 30000;
												}
											}

											if (pp < 20000)
											{
												mPoint[i].updated = 0;
											}
										}
										curren_start_ptr = curren_start_ptr->next;
									}
								}
							}
					}
			}
	}

	for (int tt = 2; tt < start_point_count+2; tt++)
	{
		LINEINFO *start_ptr;
		int total_sum=0;
		int result_num[10] = { 2, 3, 5, 7, 11, 13, 17, 19, 23, 29 };
		start_ptr = mPoint[tt].start_ptr;
		while (start_ptr != NULL){
			total_sum = total_sum + start_ptr->sum_count;
			start_ptr = start_ptr->next;
		}
		printf("%d ", total_sum%result_num[tt - 2]);
		fprintf(file_out,"%d ", total_sum%result_num[tt-2]);

	}
	printf("\r\n");
	fprintf(file_out,"\r\n");

	LINEINFO *free_temp;
	LINEINFO *free_start_ptr = mPoint[i].start_ptr;

	while (free_start_ptr != NULL)
	{
		free_temp = free_start_ptr->next;
		free(free_start_ptr);
		free_start_ptr = free_temp;
	}

}



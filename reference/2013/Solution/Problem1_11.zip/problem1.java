
import java.io.*;
import java.text.DecimalFormat;
import java.util.Collections;
import java.util.Comparator;
import java.util.StringTokenizer;
import java.util.Vector;

class CProcess {
	public String mAppName;
	public int startTick;
	public int endTick;
	public int cpu;
	public float avgCpu;
	
	public float cpuAtTick;
	
	public CProcess() {
		
	}
};

class CProcComparator implements Comparator {
	
	public int compare(Object arg0, Object arg1) {
		
		CProcess proc1 = (CProcess)arg0;
		CProcess proc2 = (CProcess)arg1;
		
		if( proc1.cpuAtTick == proc2.cpuAtTick)
		{
			return proc1.mAppName.compareTo(proc2.mAppName);
		}
		
		return 0;
	}
};

public class problem1 {

	public static void main(String[] args)
	{
		BufferedReader fin = null;
		PrintWriter fout = null;
		
		String INPUT_FILE = "input.txt";
		String OUTPUT_FILE = "output.txt";
		
		Vector<Integer> clock_ticks = new Vector<Integer>();
		Vector<CProcess>  processList = new Vector<CProcess>();
		
		try
		{
			fin = new BufferedReader(new FileReader(new File(INPUT_FILE)));
			fout = new PrintWriter(new FileWriter(new File(OUTPUT_FILE)));
			
			// read the first line
			//
			String firstLine = fin.readLine();
		
			StringTokenizer st = new StringTokenizer(firstLine);
			while(st.hasMoreTokens())
			{
				String token = st.nextToken();
				token = token.trim();
				
				clock_ticks.addElement(new Integer(Integer.parseInt(token)));
			}
			
			String line = null;
			while(true)
			{
				line = fin.readLine();
				if(line == null)
				{
					break;
				}
				
				st = new StringTokenizer(line);
				
				CProcess proc = new CProcess();
				
				// appName
				proc.mAppName = st.nextToken();
				
				// startTick;
				proc.startTick = Integer.parseInt(st.nextToken());
				
				// endTick
				proc.endTick = Integer.parseInt(st.nextToken());
				
				// cpuUsage
				proc.cpu = Integer.parseInt(st.nextToken());
				
				float fStartTick = (float)proc.startTick;
				float fEndTick = (float)proc.endTick;
				float fCpu = (float)proc.cpu;
				proc.avgCpu = fCpu / (fEndTick - fStartTick);
				
				processList.addElement(proc);
			}
			
			// Calculate right now...
			//
			
			for(int n = 0; n < clock_ticks.size(); n++ )
			{
				Integer oTick = clock_ticks.elementAt(n);
				
				int nTick = oTick.intValue();
				
				int m = 0;
				float total_cpu = 0;
				
				for(m=0; m < processList.size(); m++)
				{
					CProcess proc = processList.elementAt(m);
					
					if( nTick>=proc.startTick && nTick<proc.endTick)
					{
						total_cpu += proc.avgCpu;
					}
				}
				
				
				Vector<CProcess> outputList = new Vector<CProcess>();
				
				for(m=0; m < processList.size(); m++)
				{
					CProcess proc = processList.elementAt(m);
					proc.cpuAtTick = 0.0f;
					
					if( nTick>=proc.startTick && nTick<proc.endTick)
					{
						proc.cpuAtTick = 100.0f * (proc.avgCpu / total_cpu);
					}
					
					//proc.cpuAtTick = 50.54f;
					//proc.cpuAtTick = 50.55f;
					
					int cpuAtTick = (int)(proc.cpuAtTick * 100.0f); 
					
					proc.cpuAtTick = cpuAtTick / 10.0f;
					proc.cpuAtTick = Math.round(proc.cpuAtTick);
					proc.cpuAtTick /= 10.0f;
					
					proc.cpuAtTick = Float.parseFloat(String.format("%.1f", proc.cpuAtTick));
					
					if( proc.cpuAtTick != 0.0f)
					{
						
						DecimalFormat df = new DecimalFormat("00.0");
						//fout.println(proc.mAppName + " " + df.format(proc.cpuAtTick) + "%");
						//System.out.println(proc.mAppName + " " + df.format(proc.cpuAtTick) + "%");
						
						outputList.addElement(proc);
					}
				}
				
				// Sorting outputList
				//
				Collections.sort(outputList, new CProcComparator());
				
				// Print now... 
				//
				fout.println(nTick);
				for(int k=0; k < outputList.size(); k++)
				{
					CProcess proc = outputList.elementAt(k);
					
					int lastDigit = (int)(proc.cpuAtTick * 10.0f); 
					lastDigit = lastDigit % 10;
					
					if( lastDigit == 0 )
					{
						DecimalFormat df = new DecimalFormat("00");
						fout.println(proc.mAppName + " " + df.format(proc.cpuAtTick) + "%");
					}
					else
					{
						DecimalFormat df = new DecimalFormat("00.0");
						fout.println(proc.mAppName + " " + df.format(proc.cpuAtTick) + "%");
					}
				}
				
				fout.println();
			}
			
			fin.close();
			fout.flush();
			fout.close();
			
			System.out.println("ó�� ��. ����� output.txt �� �����ϼ���.");
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
}

#define _CRT_SECURE_NO_WARNINGS

#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#define debugprint( __X__ )		//printf __X__

enum
{
	FALSE		= 0,
	TRUE		= 1,
	HEAD_NODE	= 0,
	END_NODE	= 1,
	DEF_PATHCNT	= 1
};

typedef struct ResultSet
{
	int nValid;
	int nRemainder;

} ResultSet;

void CalcPathsAndRemainderResult( int *ppnWebPageMatrix, int nNumOfpages, int nMaxStartPoints, int nMaxLinksPerPath, ResultSet *pastResult )
{
	int *panLoop;
	int nLength			= 1;
	int nLoop;
	int nPageJump		= nNumOfpages + 1;
	int nValue;
	int nCheckBreak;
	int anDivisor[ ]	= { 2, 3, 5, 7, 11, 13, 17, 19, 23, 29 };
	int nRemainderIdx	= 0;
	int nWrapDetect		= FALSE;

	panLoop = ( int * ) malloc( sizeof( int ) * nMaxLinksPerPath );

	if( ppnWebPageMatrix && panLoop && nNumOfpages && nMaxLinksPerPath && pastResult )
	{
		for( nLoop = 1; nLoop <= nNumOfpages; ++nLoop )
		{
			ppnWebPageMatrix[ nLoop ] = 0;
		}

		for( nLength = 1; nLength <= nMaxLinksPerPath; ++nLength )
		{
			for( nLoop = 0; nLoop < nLength; ++nLoop )
			{
				panLoop[ nLoop ] = 1;
			}

			while( TRUE )
			{
				nValue = 1;

				for( nLoop = 0; nLoop < nLength; ++nLoop )
				{
					//printf( "%d ", panLoop[ nLoop ] );

					if( 0 == nLoop )
					{
						nValue *= ppnWebPageMatrix[ panLoop[ nLoop ] * nPageJump + 1 ];
					}
					else
					{
						nValue *= ppnWebPageMatrix[ panLoop[ nLoop ] * nPageJump + panLoop[ nLoop - 1 ] ];
					}					
				}

				//printf( "\n" );

				ppnWebPageMatrix[ panLoop[ nLength - 1 ] ] += nValue;

				++panLoop[ 0 ];

				nCheckBreak = 1;

				for( nLoop = 0; nLoop < nLength; ++nLoop )
				{
					if( 0 == nLoop )
					{
						nCheckBreak = nCheckBreak && ( panLoop[ nLoop ] > nNumOfpages );
					}
					else
					{
						nCheckBreak = nCheckBreak && ( panLoop[ nLoop ] >= nNumOfpages );
					}
				}

				if( nCheckBreak )
				{
					break;
				}

				for( nLoop = 0; nLoop < nLength; ++nLoop )
				{	
					nWrapDetect = FALSE;
					if( panLoop[ nLoop ] > nNumOfpages )
					{
						panLoop[ nLoop ] = 1;
						nWrapDetect = TRUE;
					}

					if( ( nLoop + 1 ) < nLength )
					{
						if( nWrapDetect && 1 == panLoop[ nLoop ] )
						{
							++panLoop[ nLoop + 1 ];
						}
					}
				}
			}
		}
	}

	/* calculate the remainder for all the calculated paths */
	for( nLoop = 2; nLoop <= nNumOfpages; ++nLoop )
	{
		if( ppnWebPageMatrix[ nLoop ] )
		{
			pastResult[ nLoop ].nValid		= TRUE;
			pastResult[ nLoop ].nRemainder	= ppnWebPageMatrix[ nLoop ] % anDivisor[ nRemainderIdx ];
			++nRemainderIdx;

			if( nRemainderIdx >= nMaxStartPoints )
			{
				break;
			}
		}
	}

	if( panLoop )
	{
		free( panLoop );
		panLoop = NULL;
	}

	debugprint( ( "End of Calculating Paths\n" ) );
}

void MakeLink( int *ppnWebPageMatrix, int nNumOfPages, int nStartLinkNode, int nToLinkNode )
{
	int nPageJump = nNumOfPages + 1;

	if( nStartLinkNode <= nNumOfPages && nToLinkNode <= nNumOfPages )
	{
		++ppnWebPageMatrix[ nStartLinkNode * nPageJump + nToLinkNode ];
	}
}

int main( int argc, char *argv[ ] )
{
	FILE		*fp									= NULL;
	int			nLoop								= 0;
	int			nNumOfTC							= 0;
	int			nBytesRead							= 0;
	int			nPegNum								= 0;
	int			nTCLoop								= 0;
	int			nPages								= 0;
	int			nLinks								= 0;
	int			nStartPoints						= 0;
	int			nLinksPerPath						= 0;
	int			nStartLinkNode						= 0;
	int			nToLinkNode							= 0;
	int			*ppnWebPageMatrix					= NULL;
	ResultSet	*pastResultSet						= NULL;
	int			nPageJump							= 0;
	int			nFirst								= TRUE;
		
	if( argc < 2 )
	{
		printf("Invalid arguments\n");
		return 1;
	}

	fp = fopen( argv[1], "r" );

	if( NULL == fp )
	{
		printf("Invalid File\n");
		return 1;
	}

	nBytesRead = fscanf( fp, "%d", &nNumOfTC );
	debugprint(( "Total TC: %d\n", nNumOfTC ));

	if( nBytesRead && nNumOfTC )
	{
		for( nTCLoop = 0; nTCLoop < nNumOfTC; ++nTCLoop )
		{
			nBytesRead = fscanf( fp, "%d %d %d %d", &nPages, &nLinks, &nStartPoints, &nLinksPerPath );
			debugprint(( "Pages(%d) Links(%d) StartPoints(%d) LinksPerPath(%d)\n", nPages, nLinks, nStartPoints, nLinksPerPath ));

			nPageJump = nPages + 1;

			if( ( ppnWebPageMatrix = ( int * ) malloc( sizeof( int ) * nPageJump * nPageJump ) ) 
					&& ( pastResultSet = ( ResultSet * ) malloc( sizeof( ResultSet ) * nPageJump ) ) )
			{
				memset( ppnWebPageMatrix, 0, sizeof( int ) * nPageJump * nPageJump );
				memset( pastResultSet, 0, sizeof( ResultSet ) * nPageJump );

				for( nLoop = 0; nLoop < nLinks; ++nLoop )
				{
					nBytesRead = fscanf( fp, "%d %d", &nStartLinkNode, &nToLinkNode );
					debugprint(( "StartNode(%d) ToNode(%d)\n", nStartLinkNode, nToLinkNode ));

					MakeLink( ppnWebPageMatrix, nPages, nStartLinkNode, nToLinkNode );
				}

				{
					int nLoop1;
					int nLoop2;

					for( nLoop1 = 1; nLoop1 <= nPages; ++nLoop1 )
					{
						for( nLoop2 = 1; nLoop2 <= nPages; ++nLoop2 )
						{
							debugprint( ( "%d ", ppnWebPageMatrix[ nLoop1 * nPageJump + nLoop2 ] ) );
						}

						debugprint( ( "\n" ) );
					}

					debugprint( ( "\n" ) );
				}

				CalcPathsAndRemainderResult( ppnWebPageMatrix, nPages, nStartPoints, nLinksPerPath, pastResultSet );

				//nFirst = TRUE;

				for( nLoop = 2; nLoop <= nPages; ++nLoop )
				{
					if( pastResultSet[ nLoop ].nValid )
					{
/*
						if( nFirst )
						{
							nFirst = FALSE;
						}
						else
						{
							printf( " " );
						}
*/
						printf( "%d ", pastResultSet[ nLoop ].nRemainder );
					}
				}

				printf( "\n" );
			}

			if( ppnWebPageMatrix )
			{
				free( ppnWebPageMatrix );
				ppnWebPageMatrix = NULL;
			}

			if( pastResultSet )
			{
				free( pastResultSet );
				pastResultSet = NULL;
			}
		}
	}

	fclose( fp );

	return 0;
}

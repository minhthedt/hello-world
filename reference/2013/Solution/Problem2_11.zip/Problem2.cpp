#include <cstdio>
#include <vector>
#include <algorithm>



class Rect {
public:
	explicit Rect(int x = 0, int y = 0, int w = 0, int h = 0) 
		: x_(x), y_(y), w_(w), h_(h), rotate_(false) {
 
	}
 
	Rect(const Rect& other)
		: x_(other.x_), y_(other.y_), w_(other.w_), h_(other.h_), 
		rotate_(other.rotate_) {
	}
 
	bool fits_in(const Rect& outer, bool& is_rotate) {
		if ((outer.w_ >= w_) && (outer.h_ >= h_)) {
			is_rotate = false;
			return true;
		}
		if ((outer.h_ >= w_) && (outer.w_ >= h_)) {
			is_rotate = true;
			return true;
		}
		return false;
	}
 
	bool same_size_as(const Rect& other, bool& is_rotate) {
		if ((w_ == other.w_) && (h_ == other.h_)) {
			is_rotate = false;
			return true;
		}
		if ((w_ == other.h_) && (h_ == other.w_)) {
			is_rotate = true;
			return true;
		}
		return false;
	}
 
	void rotate(void) {
		std::swap(w_, h_);
		rotate_ = !rotate_;
	}
 
	int x_;
	int y_;
	int w_;
	int h_;
	bool rotate_;
};



class Node {
public:
	Node(const Rect* rect)
		: rect_(rect), left_(0), right_(0), filled_(false) {
	}
	~Node(void) {
		delete rect_;
		delete left_;
		delete right_;
	}
 
	const Rect* insert(Rect* input_rect, int& out_rigth, int& out_bottom) {
		if (left_ != 0 || right_ != 0) {
			const Rect* tmp = left_->insert(input_rect, out_rigth, out_bottom);
			if (tmp == 0) {
				return right_->insert(input_rect, out_rigth, out_bottom);
			}
			return tmp;
		} else {
 
			if (filled_) {
				return 0;
			}
 
			bool is_rotate = false;
			if (!input_rect->fits_in(*rect_, is_rotate)) {
				return 0;
			}
 
			if (input_rect->same_size_as(*rect_, is_rotate)) {
				filled_ = true;
 
				// Save pos to origin memory by input_rect, 
				// pointer of Rect object in vector
				input_rect->x_ = rect_->x_;
				input_rect->y_ = rect_->y_;
				if (is_rotate) {
					input_rect->rotate();
				}
				out_rigth = std::max(out_rigth, rect_->x_ + input_rect->w_);
				out_bottom = std::max(out_bottom, rect_->y_ + input_rect->h_);
 
				return rect_;
			}
 
			if (is_rotate) {
				input_rect->rotate();
			}
 
			int w_diff = rect_->w_ - input_rect->w_;
			int h_diff = rect_->h_ - input_rect->h_;
			Rect* left_rect(new Rect(*rect_));
			Rect* right_rect(new Rect(*rect_));
 
			if (w_diff > h_diff) {
				left_rect->w_ = input_rect->w_;
				right_rect->x_ += input_rect->w_;
				right_rect->w_ -= input_rect->w_;
			} else {
				left_rect->h_ = input_rect->h_;
				right_rect->y_ += input_rect->h_;
				right_rect->h_ -= input_rect->h_;
			}
 
			left_ = new Node(left_rect);
			right_ = new Node(right_rect);
 
			return left_->insert(input_rect, out_rigth, out_bottom);
		}
	}
 
	const Rect* rect_;
	Node* left_;
	Node* right_;
	bool  filled_;
};



typedef std::vector<Rect*> BoxList;
typedef BoxList::const_iterator BoxItr;

void copy_box_list(const BoxList& lhs, BoxList& rhs) {
	BoxItr itr = lhs.begin();
	BoxItr end = lhs.end();
	for ( ; itr != end; ++itr) {
		Rect* rect(new Rect(**itr));
		rhs.push_back(rect);
	}
}

void clear_box_list(BoxList& box_list) {
	BoxItr itr = box_list.begin();
	BoxItr end = box_list.end();
		for ( ; itr != end; ++itr) {
		delete *itr;
	}
	box_list.clear();
}



BoxList box_input;

int sum_of_long = 0;
int sum_of_short = 0;
int longest_side = 0;
int longest_of_shorts = 0;

int min_area = 1000*1000;
int min_case_width = 0;
int min_case_height = 0;
BoxList min_case;

bool find_min_area(int width, int height);

void get_inputs(FILE* fp) {
	
	int loop;
	fscanf(fp, "%d", &loop);
	while (loop--) {
		Rect* box = new Rect();
		fscanf(fp, "%d %d\n", &(box->w_), &(box->h_));
		box_input.push_back(box);

		const int longer = std::max(box->w_, box->h_);
		const int shorter = std::min(box->w_, box->h_);
		longest_side = std::max(longest_side, longer);
		longest_of_shorts = std::max(longest_of_shorts, shorter);
		sum_of_long += longer;
		sum_of_short += shorter;
	}

	if ((sum_of_long*longest_of_shorts) < (sum_of_short*longest_side)) {
		find_min_area(sum_of_long, longest_of_shorts);
	} else {
		find_min_area(sum_of_short, longest_side);
	}
};

class Compare {
public:
	bool operator() (const Rect* lhs, const Rect* rhs) {
		return (lhs->w_ * lhs->h_) > (rhs->w_ * rhs->h_);
	}
} compare;

bool find_min_area(int width, int height) {

	BoxList box_list(box_input);
	std::sort(box_list.begin(), box_list.end(), compare);
	
	Rect* outline(new Rect(0, 0, width, height));
	Node* root_node(new Node(outline));
	
	bool found = true;
	BoxItr itr = box_list.begin();
	BoxItr end = box_list.end();
	for ( ; itr != end; ++itr) {
		if (root_node->insert(*itr, width, height) == 0) {
			found = false;
			break;
		}
	}
	
	if (found) {
		found = false;
		if (min_area > (width*height)) {
			min_area = width * height;
			min_case_width = width;
			min_case_height = height;

			clear_box_list(min_case);
			copy_box_list(box_input, min_case);
			found = true;
		}
	}

	delete root_node;
	return found;
}

void print_out(const BoxList& box_list) {
	BoxItr itr = box_list.begin();
	BoxItr end = box_list.end();
	for ( ; itr != end; ++itr) {
		Rect* box = *itr;
		printf("%d %d %d\n", box->x_, box->y_, (box->rotate_ ? 1 : 0));
	}
}



void make() {
	int width = sum_of_long;
	while (width-->longest_of_shorts) {
		int height = longest_of_shorts+1;
		while (height++ < sum_of_long) {
			if (find_min_area(width, height)) {
				break;
			}
		}
	}
}



int main(void) {

	FILE* fp = fopen("Problem2.txt", "r");
	get_inputs(fp);
	fclose(fp);

	make();
	
	printf("%d %d\n", min_case_width, min_case_height);
	print_out(min_case);
	clear_box_list(min_case);
 
	return 0;
}

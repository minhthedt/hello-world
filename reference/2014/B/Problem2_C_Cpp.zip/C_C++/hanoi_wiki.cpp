// http://en.wikipedia.org/wiki/Tower_of_Hanoi#Simpler_statement_of_iterative_solution

#include <iostream>
#include <stack>
#include <vector>
#include <cassert>
using namespace std;

const int NPEG = 3;
const int LARGE = 100001;

const int debug = 0;

void print_pegs(const vector<stack<int> >& pegs)
{
    if (!debug)
        return;

    for (int i = 0; i < pegs.size(); ++i) {
        stack<int> peg(pegs[i]);
        cout << "peg[" << i << "]: ";
        while (!peg.empty()) {
            cout << peg.top() << " ";
            peg.pop();
        }
        cout << endl;
    }
    cout << "--------------------------------------------------" << endl;
}

bool check_order(const vector<stack<int> >& pegs)
{
    for (int i = 0; i < pegs.size(); ++i) {
        stack<int> s(pegs[i]);
        if (s.empty())
            continue;

        int prev_top = s.top();
        s.pop();
        while (!s.empty()) {
            int top = s.top();
            s.pop();
            // assert(prev_top < top);
            if (prev_top >= top)
                return false;
        }
    }
    return true;
}

bool check_fast(const vector<stack<int> >& begin, const vector<stack<int> >& end, int n)
{
    if (!check_order(begin))
        return false;
    if (!check_order(end))
        return false;

    return true;
}

void get_method(int n, int method, int &i, int &j)
{
    if (n % 2 == 1) {
        switch(method) {
        case 0:
            i = 0; j = 1; break;
        case 1:
            i = 0; j = 2; break;
        case 2:
            i = 1; j = 2; break;
        default:
            // assert(false);
            break;
        }
    } else {
        switch(method) {
        case 0:
            i = 0; j = 2; break;
        case 1:
            i = 0; j = 1; break;
        case 2:
            i = 2; j = 1; break;
        default:
            // assert(false);
            break;
        }
    }
}

// TODO: Can grow from 'end' to 'begin', but I didn't try because N is
// really 100000 in large input, which makes me frustrated.
bool hanoi(const vector<stack<int> >& begin, const vector<stack<int> >& end, int n, int method)
{
    const int N = n;
    const int dest_peg = 1;

    vector<stack<int> > pegs(begin);

    int i = 0, j = 1;
    get_method(N, method, i, j);

    int cnt = 0;
    while (pegs[dest_peg].size() != N) {
        print_pegs(pegs);

        stack<int>& l = pegs[i];
        stack<int>& r = pegs[j];
        int ltop = l.empty() ? LARGE : l.top();
        int rtop = r.empty() ? LARGE : r.top();

        if (ltop > rtop) {
            l.push(rtop);
            r.pop();
        } else if (rtop > ltop) {
            r.push(ltop);
            l.pop();
        } else {
            // assert(false);
            return false;
        }

        if (pegs == begin)
            return false;

        if (pegs == end)
            return true;

        if (N % 2 == 1) {
            if (i == 0 && j == 1)
                j = 2;
            else if (i == 0 && j == 2)
                i = 1;
            else if (i == 1 && j == 2)
                i = 0, j = 1;
            else {
                return false;
                // assert(false);
            }
        } else {
            if (i == 0 && j == 2)
                j = 1;
            else if (i == 0 && j == 1)
                i = 2;
            else if (i == 2 && j == 1)
                i = 0, j = 2;
            else {
                return false;
                // assert(false);
            }
        }
        cnt++;
    }
    print_pegs(pegs);
    if (debug)
        cout << "Count: " << cnt << endl;

    return false;
}

bool try_hanoi(const vector<stack<int> >& begin, const vector<stack<int> >& end, int n)
{
    if (!check_fast(begin, end, n))
        return false;

    for (int i = 0; i < 3; ++i)
        if (hanoi(begin, end, n, i))
            return true;

    return false;
}

int solve(const vector<int>& disc1, const vector<int>& disc2, int n)
{
    // assert(disc1.size() == disc2.size() && disc2.size() == n);
    const int npeg = NPEG;

    vector<stack<int> > pegs1(npeg);
    vector<stack<int> > pegs2(npeg);

    int disc_size = n;
    for (int i = 0; i < disc_size; ++i) {
        int disc_no = disc_size - i;
        int peg_no = disc1[i] - 1;
        pegs1[peg_no].push(disc_no);
    }

    for (int i = 0; i < disc_size; ++i) {
        int disc_no = disc_size - i;
        int peg_no = disc2[i] - 1;
        pegs2[peg_no].push(disc_no);
    }

    if (pegs1 == pegs2)
        return 0;

    return try_hanoi(pegs1, pegs2, n) ? 1 : 0;
}

int main()
{
    int ncase;
    cin >> ncase;
    while (ncase--) {
        int ndisc;
        cin >> ndisc;

        int count = ndisc;

        vector<int> disc1;
        while (count--) {
            int peg;
            cin >> peg;
            disc1.push_back(peg);
        }

        count = ndisc;
        vector<int> disc2;
        while (count--) {
            int peg;
            cin >> peg;
            disc2.push_back(peg);
        }

        int ret = solve(disc1, disc2, ndisc);
        cout << ret << endl;
    }
    return 0;
}


#include <stdio.h>
#include <stdlib.h>
#include <vector>
#include <algorithm>

typedef long long           I64;
typedef unsigned long long  UI64;

using namespace std;

int gN;
int gP1[110000];
int gP2[110000];

const int gOther[][4] =
{
    { 0, 0, 0, 0 },
    { 0, 0, 3, 2 },
    { 0, 3, 0, 1 },
    { 0, 2, 1, 0 }
};

struct StackT
{
    int from;
    int to;
};
StackT gStack[110000];


bool isOptimal(int p[])
{
    int from = 1, to = 2;
    int other;

    for (int i = 0; i < gN; i++)
    {
        other = gOther[from][to];

        if (p[i] == from)
            to = other;
        else if (p[i] == to)
            from = other;
        else
            return false;
    }
    return true;
}

bool isValidOrder()
{
    int from = 1, to = 2;
    int other;

    for (int i = 0; i < gN; i++)
    {
        other = gOther[from][to];

        if (gP1[i] == from)
        {
            if (gP2[i] == from)
                to = other;
            else
                return true;
        }
        else
        {
            if (gP2[i] == from)
                return false;
            else
                from = other;
        }
    }

    return true;
}

int check(void)
{
    if (!isOptimal(gP1))
        return 0;

    if (!isOptimal(gP2))
        return 0;

    if (!isValidOrder())
        return 0;

    return 1;
}

void process(FILE* pfIn, FILE* pfOut)
{
    int i, j, count;

    fscanf(pfIn, "%d", &count);
    for (i = 1; i <= count; i++)
    {
        fscanf(pfIn, "%d", &gN);
        for (j = 0; j < gN; j++)
            fscanf(pfIn, "%d", &gP1[j]);
        for (j = 0; j < gN; j++)
            fscanf(pfIn, "%d", &gP2[j]);
        
        fprintf(pfOut, "%d\n", check());
    }
}

//-----------------------------------------------------------------------------

void process(const char* pcszInFile, const char* pcszOutFile)
{
    FILE* pfIn = fopen(pcszInFile, "rt");
    if (pfIn == NULL)
    {
        printf("file not found! \"%s\"\n", pcszInFile);
        exit(-2);
    }

    FILE* pfOut = fopen(pcszOutFile, "wt");
    if (pfOut == NULL)
    {
        printf("can't create file! \"%s\"\n", pcszOutFile);
        exit(-3);
    }

    process(pfIn, pfOut);

    fclose(pfIn);
    fclose(pfOut);
}

void main(int argc, char* argv[])
{
    if (argc != 3)
    {
        printf("Usage : %s <input_file> <output_file>\n", argv[0]);
        exit(-1);
    }

    process(argv[1], argv[2]);
}

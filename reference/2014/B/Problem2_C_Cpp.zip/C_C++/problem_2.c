#include <stdio.h>
#include <stdlib.h>
#include <conio.h>
#include <string.h> 
#include <time.h>

#pragma warning(disable: 4996)

void read_a_case(FILE *TC, FILE *file_out);
int verifyHanoi(int nDisk, int *disk);

#define nMAX	200000;

int *disk = NULL;

void main(int argc, char *argv[])
{
	int nCase; 
	int i = 0;

	FILE *fp_tc, *fp_result;

	fp_tc = fopen("d:\\B-small.in", "r");
	fp_result = fopen("d:\\result.txt", "w");

	fscanf(fp_tc, "%d\n", &nCase);

	if ((disk = (int *)malloc((200000)* sizeof(int))) == NULL){
			fprintf(stderr, " allocation failed!\n"); exit(1);
	}

	for (i = 0; i < nCase; i++)
	{
		read_a_case(fp_tc, fp_result);
	}

	free(disk);
	fclose(fp_tc);
	fclose(fp_result);
}

void read_a_case(FILE *TC, FILE *file_out)
{
	int nDisk; //disk count
	int i = 0;
	int result = 0;

	fscanf(TC, "%d\n", &nDisk);

	for (i = 0; i < nDisk * 2; i++)
	{
		fscanf(TC, "%d\n", disk + i);
		if (*(disk + i) == 2) *(disk + i) = 3;
		else if (*(disk + i) == 3) *(disk + i) = 2;
		else *(disk + i) = 1;
	}

	result = verifyHanoi(nDisk, disk);

	fprintf(file_out, "%d\n", result);
	printf("%d\n", result);
}


int verifyHanoi(int nDisk, int *disk)
{
	int i, *a, *b, *c, *p, *from, *to, *sp, n, n1, n2;
	int T = 0, *place, count = 0, j = 0, verCount = 0;	//������ ���� ���� ��ġ ����
	int verified = 1;
	int cmp = 0;

	n = nDisk;
	n1 = n + 1;
	n2 = n + 2;

	if ((a = (int *)malloc((n + 3) * sizeof(int))) == NULL) 
	{
		printf("allocation failed!\n"); exit(1);
	}

	if ((b = (int *)malloc((n + 3) * sizeof(int))) == NULL)
	{
		printf("allocation failed!\n"); exit(1);
	}

	if ((c = (int *)malloc((n + 3) * sizeof(int))) == NULL)
	{
		printf("allocation failed!\n"); exit(1);
	}

	if ((place = (int *)malloc((n + 3) * sizeof(int))) == NULL)
	{
		printf("allocation failed!\n"); exit(1);
	}

	a[0] = 1; b[0] = c[0] = n1;
	a[n1] = b[n1] = c[n1] = n1;
	a[n2] = 1; b[n2] = 2; c[n2] = 3;
	for (i = 1; i<n1; i++) {
		a[i] = i; b[i] = c[i] = 0;
		place[i] = 1;
	}

	from = a;
	if (n & 1) { to = c; sp = b; }
	else    { to = b; sp = c; }

	i = from[from[0]];

	while (c[0]>1) {
		i = from[from[0]++];
		place[i] = to[n2];

		//count �� ���� ũ��
		for (count = n, j = verCount; count > 0; count--, j++)
		{
			if (verified == 1)
			{
				if (*(disk + j) != place[count]) verified = 0;
				cmp++;
			}
		}

		if (verified == 1){
			if (verCount == nDisk)
			{
				free(a); free(b); free(c); free(place);
				return 1;
			}
			verCount = nDisk;
		}
		else verified = 1;

		p = sp;
		if ((to[--to[0]] = i) & 1) {
			sp = to;
			if (from[from[0]] > p[p[0]]) { to = from; from = p; }
			else to = p;
		}
		else { sp = from; from = p; }
	}

	free(a); free(b); free(c); free(place);
	return 0;
}
